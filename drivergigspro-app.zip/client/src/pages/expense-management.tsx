import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { 
  DollarSign, 
  Plus, 
  Edit, 
  Trash2, 
  Calendar,
  Search,
  Filter,
  Download,
  Upload,
  Receipt,
  Car,
  Fuel,
  Wrench,
  Coffee,
  Phone,
  CreditCard,
  Landmark,
  FileText,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Link,
  Eye,
  Calculator,
  PieChart
} from "lucide-react";
import { useState } from "react";

// Sample expense data
const sampleExpenses = [
  {
    id: 1,
    date: "2024-12-20",
    category: "Vehicle Maintenance",
    subcategory: "Oil Change",
    amount: 35.99,
    description: "Regular oil change at Valvoline Instant Oil Change",
    vendor: "Valvoline",
    paymentMethod: "Debit Card",
    taxDeductible: true,
    deductionPercentage: 100,
    receipt: "receipt_001.jpg",
    mileage: 2450,
    tags: ["maintenance", "oil", "vehicle"],
    businessPurpose: "Vehicle maintenance for delivery driving"
  },
  {
    id: 2,
    date: "2024-12-19",
    category: "Fuel",
    subcategory: "Gasoline",
    amount: 42.50,
    description: "Gas fill-up for delivery routes",
    vendor: "Shell",
    paymentMethod: "Credit Card",
    taxDeductible: true,
    deductionPercentage: 85,
    receipt: "receipt_002.jpg",
    mileage: 2420,
    tags: ["fuel", "gas", "driving"],
    businessPurpose: "Fuel for DoorDash and Uber deliveries"
  },
  {
    id: 3,
    date: "2024-12-18",
    category: "Phone & Internet",
    subcategory: "Mobile Phone",
    amount: 75.00,
    description: "Monthly phone bill - business use portion",
    vendor: "Verizon",
    paymentMethod: "Bank Transfer",
    taxDeductible: true,
    deductionPercentage: 60,
    receipt: "receipt_003.pdf",
    mileage: null,
    tags: ["phone", "communication", "monthly"],
    businessPurpose: "Phone service for gig work coordination"
  },
  {
    id: 4,
    date: "2024-12-17",
    category: "Meals",
    subcategory: "Business Meals",
    amount: 12.99,
    description: "Lunch during long delivery shift",
    vendor: "McDonald's",
    paymentMethod: "Cash",
    taxDeductible: true,
    deductionPercentage: 50,
    receipt: null,
    mileage: 2380,
    tags: ["meal", "break", "shift"],
    businessPurpose: "Meal during extended work hours"
  },
  {
    id: 5,
    date: "2024-12-16",
    category: "Vehicle Insurance",
    subcategory: "Commercial Coverage",
    amount: 185.00,
    description: "Monthly commercial vehicle insurance",
    vendor: "State Farm",
    paymentMethod: "Bank Transfer",
    taxDeductible: true,
    deductionPercentage: 100,
    receipt: "receipt_005.pdf",
    mileage: null,
    tags: ["insurance", "vehicle", "monthly"],
    businessPurpose: "Commercial insurance for rideshare driving"
  }
];

// Expense categories with tax deduction information
const expenseCategories = [
  {
    name: "Vehicle Maintenance",
    subcategories: ["Oil Change", "Tire Replacement", "Brake Service", "General Repair", "Car Wash"],
    defaultDeductible: true,
    defaultPercentage: 100,
    description: "Vehicle maintenance and repair costs"
  },
  {
    name: "Fuel",
    subcategories: ["Gasoline", "Diesel", "Electric Charging"],
    defaultDeductible: true,
    defaultPercentage: 100,
    description: "Fuel costs for business driving"
  },
  {
    name: "Vehicle Insurance",
    subcategories: ["Commercial Coverage", "Liability", "Comprehensive"],
    defaultDeductible: true,
    defaultPercentage: 100,
    description: "Commercial vehicle insurance premiums"
  },
  {
    name: "Phone & Internet",
    subcategories: ["Mobile Phone", "Internet Service", "Data Plan"],
    defaultDeductible: true,
    defaultPercentage: 60,
    description: "Communication services for business use"
  },
  {
    name: "Parking & Tolls",
    subcategories: ["Parking Fees", "Toll Roads", "Parking Meters"],
    defaultDeductible: true,
    defaultPercentage: 100,
    description: "Parking and toll expenses during work"
  },
  {
    name: "Equipment",
    subcategories: ["Phone Mount", "Dash Cam", "GPS Device", "Cooler Bag"],
    defaultDeductible: true,
    defaultPercentage: 100,
    description: "Equipment purchases for gig work"
  },
  {
    name: "Meals",
    subcategories: ["Business Meals", "Client Entertainment"],
    defaultDeductible: true,
    defaultPercentage: 50,
    description: "Meals during business hours (50% deductible)"
  },
  {
    name: "Office Supplies",
    subcategories: ["Cleaning Supplies", "Paper Products", "Storage"],
    defaultDeductible: true,
    defaultPercentage: 100,
    description: "Supplies for vehicle and business operations"
  }
];

const paymentMethods = ["Cash", "Credit Card", "Debit Card", "Bank Transfer", "PayPal", "Venmo"];

export default function ExpenseManagement() {
  const [expenses, setExpenses] = useState(sampleExpenses);
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [showEditExpense, setShowEditExpense] = useState(false);
  const [editingExpense, setEditingExpense] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [dateRange, setDateRange] = useState("this-month");
  const [viewMode, setViewMode] = useState<"list" | "summary">("list");

  const [newExpense, setNewExpense] = useState({
    date: "",
    category: "",
    subcategory: "",
    amount: "",
    description: "",
    vendor: "",
    paymentMethod: "",
    taxDeductible: true,
    deductionPercentage: 100,
    mileage: "",
    tags: "",
    businessPurpose: ""
  });

  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = expense.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         expense.vendor.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || expense.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const totalExpenses = filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const totalDeductible = filteredExpenses.reduce((sum, expense) => 
    sum + (expense.taxDeductible ? expense.amount * (expense.deductionPercentage / 100) : 0), 0
  );

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Vehicle Maintenance": return <Wrench className="text-blue-600" size={16} />;
      case "Fuel": return <Fuel className="text-red-600" size={16} />;
      case "Vehicle Insurance": return <Car className="text-green-600" size={16} />;
      case "Phone & Internet": return <Phone className="text-purple-600" size={16} />;
      case "Meals": return <Coffee className="text-orange-600" size={16} />;
      default: return <Receipt className="text-gray-600" size={16} />;
    }
  };

  const handleAddExpense = () => {
    const expense = {
      id: Date.now(),
      ...newExpense,
      amount: parseFloat(newExpense.amount),
      mileage: newExpense.mileage ? parseInt(newExpense.mileage) : null,
      tags: newExpense.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      receipt: null
    };
    setExpenses([expense, ...expenses]);
    setNewExpense({
      date: "",
      category: "",
      subcategory: "",
      amount: "",
      description: "",
      vendor: "",
      paymentMethod: "",
      taxDeductible: true,
      deductionPercentage: 100,
      mileage: "",
      tags: "",
      businessPurpose: ""
    });
    setShowAddExpense(false);
  };

  const handleEditExpense = () => {
    const updatedExpenses = expenses.map(expense =>
      expense.id === editingExpense.id ? {
        ...editingExpense,
        amount: parseFloat(editingExpense.amount.toString()),
        mileage: editingExpense.mileage ? parseInt(editingExpense.mileage.toString()) : null,
        tags: typeof editingExpense.tags === 'string' 
          ? editingExpense.tags.split(',').map((tag: string) => tag.trim()).filter((tag: string) => tag)
          : editingExpense.tags
      } : expense
    );
    setExpenses(updatedExpenses);
    setShowEditExpense(false);
    setEditingExpense(null);
  };

  const handleDeleteExpense = (id: number) => {
    setExpenses(expenses.filter(expense => expense.id !== id));
  };

  const ExpenseForm = ({ expense, setExpense, isEdit = false }: any) => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="date">Date *</Label>
          <Input
            id="date"
            type="date"
            value={expense.date}
            onChange={(e) => setExpense({...expense, date: e.target.value})}
          />
        </div>
        <div>
          <Label htmlFor="amount">Amount *</Label>
          <Input
            id="amount"
            type="number"
            step="0.01"
            placeholder="0.00"
            value={expense.amount}
            onChange={(e) => setExpense({...expense, amount: e.target.value})}
          />
        </div>
        <div>
          <Label htmlFor="category">Category *</Label>
          <Select value={expense.category} onValueChange={(value) => {
            const category = expenseCategories.find(cat => cat.name === value);
            setExpense({
              ...expense, 
              category: value,
              subcategory: "",
              taxDeductible: category?.defaultDeductible || false,
              deductionPercentage: category?.defaultPercentage || 0
            });
          }}>
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {expenseCategories.map(category => (
                <SelectItem key={category.name} value={category.name}>
                  {category.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="subcategory">Subcategory</Label>
          <Select value={expense.subcategory} onValueChange={(value) => setExpense({...expense, subcategory: value})}>
            <SelectTrigger>
              <SelectValue placeholder="Select subcategory" />
            </SelectTrigger>
            <SelectContent>
              {expense.category && expenseCategories
                .find(cat => cat.name === expense.category)?.subcategories
                .map((sub: string) => (
                  <SelectItem key={sub} value={sub}>{sub}</SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="vendor">Vendor/Merchant</Label>
          <Input
            id="vendor"
            value={expense.vendor}
            onChange={(e) => setExpense({...expense, vendor: e.target.value})}
            placeholder="Shell, Valvoline, etc."
          />
        </div>
        <div>
          <Label htmlFor="paymentMethod">Payment Method</Label>
          <Select value={expense.paymentMethod} onValueChange={(value) => setExpense({...expense, paymentMethod: value})}>
            <SelectTrigger>
              <SelectValue placeholder="Select payment method" />
            </SelectTrigger>
            <SelectContent>
              {paymentMethods.map(method => (
                <SelectItem key={method} value={method}>{method}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="mileage">Mileage (optional)</Label>
          <Input
            id="mileage"
            type="number"
            value={expense.mileage}
            onChange={(e) => setExpense({...expense, mileage: e.target.value})}
            placeholder="Current odometer reading"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Switch
            id="taxDeductible"
            checked={expense.taxDeductible}
            onCheckedChange={(checked) => setExpense({...expense, taxDeductible: checked})}
          />
          <Label htmlFor="taxDeductible">Tax Deductible</Label>
        </div>
      </div>
      
      {expense.taxDeductible && (
        <div>
          <Label htmlFor="deductionPercentage">Deduction Percentage</Label>
          <Input
            id="deductionPercentage"
            type="number"
            min="0"
            max="100"
            value={expense.deductionPercentage}
            onChange={(e) => setExpense({...expense, deductionPercentage: parseInt(e.target.value)})}
          />
        </div>
      )}
      
      <div>
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          value={expense.description}
          onChange={(e) => setExpense({...expense, description: e.target.value})}
          placeholder="Brief description of the expense"
          rows={2}
        />
      </div>
      
      <div>
        <Label htmlFor="businessPurpose">Business Purpose</Label>
        <Textarea
          id="businessPurpose"
          value={expense.businessPurpose}
          onChange={(e) => setExpense({...expense, businessPurpose: e.target.value})}
          placeholder="Explain how this expense relates to your business"
          rows={2}
        />
      </div>
      
      <div>
        <Label htmlFor="tags">Tags (comma separated)</Label>
        <Input
          id="tags"
          value={expense.tags}
          onChange={(e) => setExpense({...expense, tags: e.target.value})}
          placeholder="maintenance, fuel, monthly"
        />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                Expense Management
              </h1>
              <p className="text-gray-600 mt-2">
                Track business expenses and maximize tax deductions for gig work
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => setShowAddExpense(true)}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
              >
                <Plus size={16} className="mr-2" />
                Add Expense
              </Button>
            </div>
          </div>
        </div>

        {/* Integration Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardContent className="p-4 text-center">
              <Landmark className="mx-auto text-blue-600 mb-2" size={24} />
              <h3 className="font-semibold text-gray-800">Connect Bank Account</h3>
              <p className="text-sm text-gray-600">Automatically import transactions</p>
              <Button variant="outline" size="sm" className="mt-2">
                <Link size={14} className="mr-1" />
                Connect
              </Button>
            </CardContent>
          </Card>
          
          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardContent className="p-4 text-center">
              <CreditCard className="mx-auto text-purple-600 mb-2" size={24} />
              <h3 className="font-semibold text-gray-800">Link Debit Cards</h3>
              <p className="text-sm text-gray-600">Track card transactions automatically</p>
              <Button variant="outline" size="sm" className="mt-2">
                <Link size={14} className="mr-1" />
                Link Cards
              </Button>
            </CardContent>
          </Card>
          
          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardContent className="p-4 text-center">
              <FileText className="mx-auto text-green-600 mb-2" size={24} />
              <h3 className="font-semibold text-gray-800">QuickBooks Sync</h3>
              <p className="text-sm text-gray-600">Sync with accounting software</p>
              <Button variant="outline" size="sm" className="mt-2">
                <Link size={14} className="mr-1" />
                Sync
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Expenses</p>
                  <p className="text-2xl font-bold text-gray-800">${totalExpenses.toFixed(2)}</p>
                </div>
                <DollarSign className="text-green-600" size={24} />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Tax Deductible</p>
                  <p className="text-2xl font-bold text-emerald-600">${totalDeductible.toFixed(2)}</p>
                </div>
                <Calculator className="text-emerald-600" size={24} />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Potential Savings</p>
                  <p className="text-2xl font-bold text-blue-600">${(totalDeductible * 0.22).toFixed(2)}</p>
                </div>
                <TrendingUp className="text-blue-600" size={24} />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Receipts Uploaded</p>
                  <p className="text-2xl font-bold text-purple-600">{expenses.filter(e => e.receipt).length}</p>
                </div>
                <Receipt className="text-purple-600" size={24} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Controls */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <Input
              placeholder="Search expenses..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {expenseCategories.map(category => (
                <SelectItem key={category.name} value={category.name}>{category.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="this-week">This Week</SelectItem>
              <SelectItem value="this-month">This Month</SelectItem>
              <SelectItem value="last-month">Last Month</SelectItem>
              <SelectItem value="this-year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              onClick={() => setViewMode("list")}
              size="sm"
            >
              List
            </Button>
            <Button
              variant={viewMode === "summary" ? "default" : "outline"}
              onClick={() => setViewMode("summary")}
              size="sm"
            >
              <PieChart size={16} className="mr-1" />
              Summary
            </Button>
          </div>
        </div>

        {/* Expense List */}
        {viewMode === "list" && (
          <div className="space-y-4">
            {filteredExpenses.map((expense) => (
              <Card key={expense.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 flex-1">
                      <div className="flex items-center space-x-2">
                        {getCategoryIcon(expense.category)}
                        <div>
                          <p className="font-semibold text-gray-800">{expense.description}</p>
                          <p className="text-sm text-gray-600">
                            {expense.vendor} • {expense.category}
                            {expense.subcategory && ` • ${expense.subcategory}`}
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="font-bold text-lg">${expense.amount.toFixed(2)}</p>
                        <p className="text-sm text-gray-600">{expense.date}</p>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        {expense.taxDeductible ? (
                          <Badge className="bg-green-500 text-white">
                            {expense.deductionPercentage}% Deductible
                          </Badge>
                        ) : (
                          <Badge variant="secondary">Not Deductible</Badge>
                        )}
                        
                        {expense.receipt && (
                          <Badge variant="outline">
                            <Receipt size={12} className="mr-1" />
                            Receipt
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingExpense({
                              ...expense,
                              tags: expense.tags.join(', ')
                            });
                            setShowEditExpense(true);
                          }}
                        >
                          <Edit size={16} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteExpense(expense.id)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {expense.businessPurpose && (
                    <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-700">
                        <strong>Business Purpose:</strong> {expense.businessPurpose}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Summary View */}
        {viewMode === "summary" && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Expenses by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {expenseCategories.map(category => {
                    const categoryExpenses = filteredExpenses.filter(e => e.category === category.name);
                    const categoryTotal = categoryExpenses.reduce((sum, e) => sum + e.amount, 0);
                    const percentage = totalExpenses > 0 ? (categoryTotal / totalExpenses) * 100 : 0;
                    
                    return (
                      <div key={category.name} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {getCategoryIcon(category.name)}
                          <span className="text-sm font-medium">{category.name}</span>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">${categoryTotal.toFixed(2)}</p>
                          <p className="text-xs text-gray-600">{percentage.toFixed(1)}%</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tax Deduction Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <span className="font-medium text-green-800">Total Deductible Amount</span>
                    <span className="font-bold text-green-800">${totalDeductible.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                    <span className="font-medium text-blue-800">Estimated Tax Savings (22%)</span>
                    <span className="font-bold text-blue-800">${(totalDeductible * 0.22).toFixed(2)}</span>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>* Tax savings estimate based on 22% tax bracket</p>
                    <p>* Consult a tax professional for accurate calculations</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Add Expense Modal */}
        <Dialog open={showAddExpense} onOpenChange={setShowAddExpense}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Plus className="text-green-600" />
                Add New Expense
              </DialogTitle>
            </DialogHeader>
            <ExpenseForm expense={newExpense} setExpense={setNewExpense} />
            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button variant="outline" onClick={() => setShowAddExpense(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleAddExpense}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
                disabled={!newExpense.date || !newExpense.amount || !newExpense.description}
              >
                <CheckCircle2 size={16} className="mr-2" />
                Add Expense
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Edit Expense Modal */}
        <Dialog open={showEditExpense} onOpenChange={setShowEditExpense}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Edit className="text-green-600" />
                Edit Expense
              </DialogTitle>
            </DialogHeader>
            {editingExpense && (
              <ExpenseForm expense={editingExpense} setExpense={setEditingExpense} isEdit={true} />
            )}
            <div className="flex justify-end gap-3 pt-6 border-t">
              <Button variant="outline" onClick={() => setShowEditExpense(false)}>
                Cancel
              </Button>
              <Button
                onClick={handleEditExpense}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
              >
                <CheckCircle2 size={16} className="mr-2" />
                Save Changes
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}