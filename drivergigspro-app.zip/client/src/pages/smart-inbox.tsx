import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Mail, 
  Inbox, 
  Bot, 
  Shield, 
  Zap, 
  Bell, 
  Search, 
  Filter, 
  ArrowRight,
  CheckCircle,
  Clock,
  Star,
  AlertTriangle,
  Brain,
  Eye,
  FileText,
  Users
} from "lucide-react";

export default function SmartInbox() {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header Section */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl mb-6 shadow-xl">
            <Mail className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent mb-4">
            Smart Inbox
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            AI-powered email management for gig workers. Automatically organize, analyze, and prioritize your job-related communications.
          </p>
          
          {/* Coming Soon Banner */}
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full text-white font-bold text-lg shadow-lg animate-pulse">
            <Clock className="h-5 w-5" />
            Coming Soon
          </div>
        </div>

        {/* Feature Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          <Card className="hover:shadow-xl transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center pb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Bot className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-xl font-bold text-gray-800">AI Email Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Automatically categorize and extract key information from job-related emails including opportunities, interviews, and deadlines.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center pb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-xl font-bold text-gray-800">Smart Filtering</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Intelligent spam filtering and priority scoring to ensure you never miss important job opportunities or deadlines.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center pb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Bell className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-xl font-bold text-gray-800">Smart Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Get notified instantly about high-priority emails like job offers, interview requests, and urgent company communications.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* How It Works Section */}
        <Card className="mb-12 border-0 bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader className="text-center pb-8">
            <CardTitle className="text-3xl font-bold text-gray-800 mb-4">How Smart Inbox Works</CardTitle>
            <p className="text-gray-600 text-lg">
              Streamline your gig work communications with intelligent email management
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Step 1 */}
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Mail className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">1. Email Integration</h3>
                <p className="text-gray-600">
                  Connect your email accounts or use our dedicated @drivergigspro.com address for job applications. All gig-related emails are automatically captured.
                </p>
              </div>

              {/* Step 2 */}
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Brain className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">2. AI Processing</h3>
                <p className="text-gray-600">
                  Our AI analyzes each email to identify job opportunities, interview invitations, pay rates, deadlines, and matches them with companies in your database.
                </p>
              </div>

              {/* Step 3 */}
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Zap className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">3. Smart Actions</h3>
                <p className="text-gray-600">
                  Get instant alerts for high-priority emails, automatic categorization, and suggested responses. Never miss an opportunity again.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Email Categories Preview */}
        <Card className="mb-12 border-0 bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-gray-800 mb-6 text-center">Email Categories & Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl border border-green-200">
                <div className="flex items-center gap-3 mb-4">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                  <h4 className="font-bold text-green-800">Job Offers</h4>
                </div>
                <p className="text-green-700 text-sm">
                  Automatic detection of hiring decisions and job confirmations
                </p>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl border border-blue-200">
                <div className="flex items-center gap-3 mb-4">
                  <Users className="h-6 w-6 text-blue-600" />
                  <h4 className="font-bold text-blue-800">Interviews</h4>
                </div>
                <p className="text-blue-700 text-sm">
                  Interview invitations and scheduling notifications
                </p>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-red-50 p-6 rounded-xl border border-orange-200">
                <div className="flex items-center gap-3 mb-4">
                  <AlertTriangle className="h-6 w-6 text-orange-600" />
                  <h4 className="font-bold text-orange-800">Urgent</h4>
                </div>
                <p className="text-orange-700 text-sm">
                  Time-sensitive communications requiring immediate attention
                </p>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-indigo-50 p-6 rounded-xl border border-purple-200">
                <div className="flex items-center gap-3 mb-4">
                  <FileText className="h-6 w-6 text-purple-600" />
                  <h4 className="font-bold text-purple-800">Documents</h4>
                </div>
                <p className="text-purple-700 text-sm">
                  Contract attachments, forms, and important paperwork
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Mockup Interface Preview */}
        <Card className="mb-12 border-0 bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-gray-800 mb-6 text-center">Interface Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-8 border-2 border-dashed border-gray-300">
              <div className="space-y-6">
                {/* Mock email list */}
                <div className="space-y-4">
                  {/* High Priority Email */}
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <div>
                        <p className="font-bold text-gray-800">DoorDash - Interview Invitation</p>
                        <p className="text-sm text-gray-600">AI detected: Interview scheduled for tomorrow 2PM</p>
                      </div>
                    </div>
                    <Badge className="bg-red-500 text-white">High Priority</Badge>
                  </div>

                  {/* Job Offer Email */}
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <div>
                        <p className="font-bold text-gray-800">Uber Eats - Welcome to the Team!</p>
                        <p className="text-sm text-gray-600">AI detected: Job offer accepted, start date mentioned</p>
                      </div>
                    </div>
                    <Badge className="bg-green-500 text-white">Job Offer</Badge>
                  </div>

                  {/* Regular Email */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <div>
                        <p className="font-bold text-gray-800">Grubhub - Weekly Performance Summary</p>
                        <p className="text-sm text-gray-600">AI extracted: $847 earnings, 4.9 rating this week</p>
                      </div>
                    </div>
                    <Badge className="bg-blue-500 text-white">Performance</Badge>
                  </div>
                </div>

                <div className="text-center text-gray-500 text-sm mt-8">
                  This is a preview of how your Smart Inbox will organize and categorize emails
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Ready to Transform Your Email Management?</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Smart Inbox will be available soon. Be the first to know when it launches and never miss another job opportunity.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              disabled
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg opacity-50 cursor-not-allowed"
            >
              <Mail className="h-5 w-5 mr-2" />
              Coming Soon
            </Button>
            
            <Button 
              variant="outline" 
              size="lg"
              className="px-8 py-4 text-lg font-bold rounded-xl border-2 border-blue-600 text-blue-600 hover:bg-blue-50"
              onClick={() => window.open('/job-boards', '_self')}
            >
              <Eye className="h-5 w-5 mr-2" />
              Explore Job Boards
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}