import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Fuel, 
  ExternalLink, 
  Truck,
  Search,
  ChevronLeft,
  Car,
  Wrench,
  Building,
  Calculator,
  MapPin,
  FileText,
  Navigation,
  Grid3X3,
  Award,
  Shield,
  Users,
  Heart,
  CreditCard
} from "lucide-react";

// Category definitions
const DRIVER_CATEGORIES = [
  {
    id: "fuel-cards",
    name: "Fuel Cards",
    icon: Fuel,
    description: "Discover and track fuel card rewards",
    count: 21,
    color: "green"
  },
  {
    id: "financial-tools",
    name: "Financial Tools",
    icon: Calculator,
    description: "Expense tracking and tax preparation",
    count: 6,
    color: "purple"
  },
  {
    id: "insurance-tax",
    name: "Insurance & Tax",
    icon: Shield,
    description: "Insurance providers and tax services",
    count: 7,
    color: "red"
  },

  {
    id: "online-resources",
    name: "Online Resources",
    icon: Grid3X3,
    description: "Useful websites and online resources for drivers",
    count: 7,
    color: "amber"
  },
  {
    id: "training-associations",
    name: "Training and Trade Associations to Join",
    icon: Users,
    description: "Professional organizations, training programs, and industry associations",
    count: 5,
    color: "teal"
  },
  {
    id: "medical-insurance",
    name: "Medical Insurance and Health Care",
    icon: Heart,
    description: "Healthcare benefits and medical cost sharing memberships",
    count: 2,
    color: "rose"
  },
  {
    id: "financial-institutions",
    name: "Financial Institutions",
    icon: CreditCard,
    description: "Banks and credit unions offering driver benefits",
    count: 1,
    color: "violet"
  },
  {
    id: "job-boards",
    name: "Job Boards",
    icon: Grid3X3,
    description: "Browse major job platforms like Indeed, ZipRecruiter, LinkedIn",
    count: 12,
    color: "blue"
  },
  {
    id: "job-posting-platforms",
    name: "Job Posting Platforms",
    icon: Building,
    description: "Specialized courier and delivery job platforms",
    count: 12,
    color: "cyan"
  }
];


export default function DriverResources() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const getGradientClasses = (color: string) => {
    const gradientMap: Record<string, string> = {
      green: "from-green-500 to-emerald-600",
      blue: "from-blue-500 to-indigo-600", 
      orange: "from-orange-500 to-red-600",
      purple: "from-purple-500 to-pink-600",
      gray: "from-gray-500 to-slate-600",
      yellow: "from-yellow-500 to-orange-600",
      red: "from-red-500 to-pink-600",
      cyan: "from-cyan-500 to-blue-600",
      indigo: "from-indigo-500 to-purple-600",
      pink: "from-pink-500 to-rose-600",
      emerald: "from-emerald-500 to-teal-600",
      amber: "from-amber-500 to-yellow-600",
      teal: "from-teal-500 to-cyan-600",
      rose: "from-rose-500 to-pink-600",
      violet: "from-violet-500 to-purple-600"
    };
    return gradientMap[color] || gradientMap.gray;
  };

  const filteredCategories = DRIVER_CATEGORIES.filter(category =>
    category.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedCategoryData = DRIVER_CATEGORIES.find(cat => cat.id === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Modern Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200/50 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-2 rounded-xl bg-gradient-to-r from-blue-500 to-indigo-600">
                <Truck className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                  Driver Resources
                </h1>
                <p className="text-sm text-gray-600">Everything you need for your driving business</p>
              </div>
            </div>
            
            {/* Search Bar */}
            <div className="relative w-80">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search categories..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/70 border-gray-200/50 focus:bg-white transition-colors"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {!selectedCategory ? (
          // Category Grid View - Main Landing
          <div className="space-y-8">
            <div className="text-center space-y-4">
              <h2 className="text-3xl font-bold text-gray-800">Choose Your Resource Category</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Browse our comprehensive collection of tools and resources organized to help you succeed in your driving business.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredCategories.map((category) => {
                const IconComponent = category.icon;
                
                return (
                  <Card 
                    key={category.id}
                    className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 bg-white/70 backdrop-blur-sm hover:bg-white/90 hover:-translate-y-1"
                    onClick={() => {
                      if (category.id === 'job-boards') {
                        window.location.href = '/job-boards';
                      } else if (category.id === 'job-posting-platforms') {
                        window.location.href = '/job-posting-platforms';
                      } else {
                        setSelectedCategory(category.id);
                      }
                    }}
                  >
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div className={`p-3 rounded-lg bg-gradient-to-r ${getGradientClasses(category.color)}`}>
                            <IconComponent className="w-6 h-6 text-white" />
                          </div>
                          <Badge variant="secondary" className="bg-gray-100 text-gray-700">
                            {category.count}
                          </Badge>
                        </div>
                        
                        <div className="space-y-2">
                          <h3 className="font-semibold text-gray-800 group-hover:text-blue-600 transition-colors">
                            {category.name}
                          </h3>
                          <p className="text-sm text-gray-600 line-clamp-2">
                            {category.description}
                          </p>
                        </div>
                        
                        <div className="flex items-center text-blue-600 text-sm font-medium group-hover:translate-x-1 transition-transform">
                          <span>Explore</span>
                          <ExternalLink className="w-4 h-4 ml-1" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        ) : (
          // Selected Category View
          <div className="space-y-6">
            {/* Back Button & Category Header */}
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                onClick={() => setSelectedCategory(null)}
                className="p-2 hover:bg-white/70"
              >
                <ChevronLeft className="w-5 h-5 mr-1" />
                Back to Categories
              </Button>
              
              <div className="flex items-center space-x-3">
                {selectedCategoryData && (
                  <>
                    <div className={`p-2 rounded-lg bg-gradient-to-r ${getGradientClasses(selectedCategoryData.color)}`}>
                      <selectedCategoryData.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-2xl font-bold text-gray-800">{selectedCategoryData.name}</h2>
                      <p className="text-gray-600">{selectedCategoryData.description}</p>
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Category Content */}
            {selectedCategory === "fuel-cards" ? (
              // Fuel Cards Section
              <div className="space-y-6">
                <div className="bg-white/70 backdrop-blur-sm rounded-xl border border-gray-200/50 p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="inline-flex p-3 rounded-full bg-gradient-to-r from-green-500 to-emerald-600">
                      <Fuel className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-800">Fuel Cards & Savings</h3>
                      <p className="text-gray-600">Maximize fuel savings with cashback apps and fuel cards</p>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {/* Upside */}
                    <Card className="border-l-4 border-green-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          Upside
                          <Badge variant="secondary">App-Based</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">
                          Up to 25¢ per gallon cash back at participating stations
                        </p>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Stackable:</span>
                            <Badge variant="outline" className="text-green-600">Yes</Badge>
                          </div>
                          <p className="text-gray-600">Works with other fuel cards and payment methods</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.upside.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit Upside
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Mudflap */}
                    <Card className="border-l-4 border-blue-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          Mudflap
                          <Badge variant="secondary">Diesel</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">
                          Save 30–50¢/gal at 1,500+ truck stops. Great for diesel cargo vans
                        </p>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Stackable:</span>
                            <Badge variant="outline" className="text-red-600">No</Badge>
                          </div>
                          <p className="text-gray-600">Must use their payment system</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.mudflap.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit Mudflap
                        </Button>
                      </CardContent>
                    </Card>

                    {/* AtoB Fuel Card */}
                    <Card className="border-l-4 border-purple-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          AtoB Fuel Card
                          <Badge variant="secondary">No Credit Check</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">
                          5–25¢ per gallon savings with expense tracking and GPS insights
                        </p>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Stackable:</span>
                            <Badge variant="outline" className="text-green-600">Yes</Badge>
                          </div>
                          <p className="text-gray-600">Works at any Visa-accepting station</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.atob.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit AtoB
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Coast Card */}
                    <Card className="border-l-4 border-orange-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          Coast Card
                          <Badge variant="secondary">Business Prepaid</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">
                          Reloadable Visa business card with custom controls and expense tracking
                        </p>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Stackable:</span>
                            <Badge variant="outline" className="text-green-600">Yes</Badge>
                          </div>
                          <p className="text-gray-600">Soft credit check only</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.coastpay.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit Coast
                        </Button>
                      </CardContent>
                    </Card>

                    {/* GasBuddy Pay */}
                    <Card className="border-l-4 border-cyan-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          GasBuddy Pay
                          <Badge variant="secondary">Bank-Linked</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">
                          Up to 25¢/gal savings plus GasBack rewards program
                        </p>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Stackable:</span>
                            <Badge variant="outline" className="text-yellow-600">Partial</Badge>
                          </div>
                          <p className="text-gray-600">Works with some rewards cards</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.gasbuddy.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit GasBuddy
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Trucker Path */}
                    <Card className="border-l-4 border-red-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          Trucker Path
                          <Badge variant="secondary">Truck Stops</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">
                          30–50¢/gal discounts at 600+ truck stops for professional drivers
                        </p>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">Stackable:</span>
                            <Badge variant="outline" className="text-red-600">No</Badge>
                          </div>
                          <p className="text-gray-600">Prepaid-style, no credit check</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.truckerpath.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit Trucker Path
                        </Button>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Stacking Strategy */}
                  <div className="mt-8 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-6 border border-green-200">
                    <h4 className="text-lg font-semibold text-green-800 mb-4 flex items-center gap-2">
                      <Award className="w-5 h-5" />
                      Suggested Stacking Strategy for Maximum Savings
                    </h4>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                          <span className="font-medium">Upside</span>
                          <span className="text-sm text-gray-600">Everyday gas cashback</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                          <span className="font-medium">AtoB Card</span>
                          <span className="text-sm text-gray-600">Universal Visa fuel card</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-white rounded-lg border">
                          <span className="font-medium">GasBuddy</span>
                          <span className="text-sm text-gray-600">Daily savings + rewards</span>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <span className="font-medium text-blue-800">Mudflap</span>
                          <span className="text-sm text-blue-600">Diesel routes only</span>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                          <span className="font-medium text-red-800">Trucker Path</span>
                          <span className="text-sm text-red-600">Truck stops only</span>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg border">
                          <p className="text-sm text-gray-600">
                            <strong>Pro Tip:</strong> Stack Upside with AtoB or Coast for maximum savings on regular routes
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : selectedCategory === "medical-insurance" ? (
              // Medical Insurance and Health Care Section
              <div className="space-y-6">
                <div className="bg-white/70 backdrop-blur-sm rounded-xl border border-gray-200/50 p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="inline-flex p-3 rounded-full bg-gradient-to-r from-rose-500 to-pink-600">
                      <Heart className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-800">Medical Insurance and Health Care</h3>
                      <p className="text-gray-600">Healthcare benefits and medical cost sharing memberships for gig workers</p>
                    </div>
                  </div>

                  <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {/* Hooray Health */}
                    <Card className="border-l-4 border-rose-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          Hooray Health
                          <Badge variant="secondary" className="bg-rose-100 text-rose-800">Healthcare Benefits</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Healthcare perks for your everyday medical needs with reliable care when and where you need it.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">$0 cost telemedicine</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">$25 per visit for retail clinics and urgent care</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">$5 or less medications</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Up to $20,000 reimbursement per accidental injury</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>No Deductibles:</strong> All benefits available without any deductibles
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://hoorayhealth.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Learn More
                        </Button>
                      </CardContent>
                    </Card>

                    {/* GigSmart OAI Coverage */}
                    <Card className="border-l-4 border-blue-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          GigSmart OAI Coverage
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">Insurance Protection</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Eligible GigSmart Shift Gig workers are protected by Occupational Accident Insurance (OAI).
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Covers independent contractors</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">No out-of-pocket medical expenses for work injuries</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Coverage while working Shift Gigs</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Eligibility:</strong> Available to qualified GigSmart workers during active shifts
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://gigsmart.com/benefits', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          View Benefits
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            ) : selectedCategory === "financial-institutions" ? (
              // Financial Institutions Section
              <div className="space-y-6">
                <div className="bg-white/70 backdrop-blur-sm rounded-xl border border-gray-200/50 p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="inline-flex p-3 rounded-full bg-gradient-to-r from-violet-500 to-purple-600">
                      <CreditCard className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-800">Financial Institutions</h3>
                      <p className="text-gray-600">Banks and credit unions offering special benefits for gig workers</p>
                    </div>
                  </div>

                  <div className="grid gap-6 md:grid-cols-1">
                    {/* Service Credit Union */}
                    <Card className="border-l-4 border-violet-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          Service Credit Union
                          <Badge variant="secondary" className="bg-violet-100 text-violet-800">Banking Partner</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          GigSmart has partnered with Service Credit Union to give all Workers access to various financial benefits.
                        </p>
                        <div className="grid gap-3 md:grid-cols-2">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">Free everyday checking</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Flexible credit cards</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">High-interest savings accounts</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Discount auto loans</span>
                          </div>
                        </div>
                        <div className="mt-4 p-3 bg-gray-50 rounded-lg border">
                          <p className="text-sm text-gray-600">
                            <strong>Partnership Benefits:</strong> Special rates and services available through GigSmart partnership
                          </p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://servicecu.org', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit Service Credit Union
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            ) : selectedCategory === "online-resources" ? (
              // Online Resources Section
              <div className="space-y-6">
                <div className="bg-white/70 backdrop-blur-sm rounded-xl border border-gray-200/50 p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="inline-flex p-3 rounded-full bg-gradient-to-r from-amber-500 to-yellow-600">
                      <Grid3X3 className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-800">Online Resources</h3>
                      <p className="text-gray-600">Useful websites and online resources for drivers</p>
                    </div>
                  </div>

                  <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {/* RockAuto */}
                    <Card className="border-l-4 border-amber-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          RockAuto
                          <Badge variant="secondary" className="bg-amber-100 text-amber-800">Auto Parts</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Online auto parts retailer with vast catalog searchable by vehicle make, model, and year. Reliably low prices with fast shipping worldwide.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">DIY-friendly with full manufacturer warranty</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Multiple quality/price tiers available</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Daily catalog updates from hundreds of manufacturers</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Ships worldwide (except Antarctica)</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Award Recognition:</strong> 2019 Best Customer Service by Newsweek in Auto Parts Retailer category
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.rockauto.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Shop Auto Parts
                        </Button>
                      </CardContent>
                    </Card>

                    {/* CarCareKiosk */}
                    <Card className="border-l-4 border-blue-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          CarCareKiosk
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">DIY Guides</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Free DIY car maintenance platform with thousands of step-by-step video tutorials tailored to specific vehicle makes, models, and years.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">Completely FREE video tutorials</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Vehicle-specific maintenance guides</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Oil changes, brake pads, filters, and more</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Cost estimation and repair tracking</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Mobile App:</strong> Available on Amazon Appstore with 4.3/5 star rating
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.carcarekiosk.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Learn Car Maintenance
                        </Button>
                      </CardContent>
                    </Card>

                  </div>
                </div>
              </div>
            ) : selectedCategory === "training-associations" ? (
              // Training and Trade Associations Section
              <div className="space-y-6">
                <div className="bg-white/70 backdrop-blur-sm rounded-xl border border-gray-200/50 p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="inline-flex p-3 rounded-full bg-gradient-to-r from-teal-500 to-cyan-600">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-800">Training and Trade Associations to Join</h3>
                      <p className="text-gray-600">Professional organizations, training programs, and industry associations</p>
                    </div>
                  </div>

                  <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                    {/* CLDA - Customized Logistics and Delivery Association */}
                    <Card className="border-l-4 border-green-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-12 h-12 rounded-lg overflow-hidden bg-white border-2 border-green-200">
                              <div className="w-10 h-10 bg-gradient-to-r from-green-600 to-emerald-700 text-white font-bold text-xs flex items-center justify-center rounded">
                                CLDA
                              </div>
                            </div>
                            <div>
                              <div className="font-semibold">CLDA</div>
                              <div className="text-sm text-gray-500 font-normal">Est. 1987</div>
                            </div>
                          </div>
                          <Badge variant="secondary" className="bg-green-100 text-green-800">Industry Association</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Customized Logistics and Delivery Association - The voice for final mile logistics and delivery companies, connecting professionals for education, networking, and industry advocacy.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">Professional development webinars and resources</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Industry networking opportunities</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Government affairs and policy advocacy</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Business opportunities and strategic planning</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Established:</strong> 1987 - Serving North American logistics professionals for 38+ years
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://clda.org', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit CLDA
                        </Button>
                      </CardContent>
                    </Card>

                    {/* ECA - Express Carriers Association */}
                    <Card className="border-l-4 border-blue-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-12 h-12 rounded-lg overflow-hidden bg-white border-2 border-blue-200">
                              <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-700 text-white font-bold text-xs flex items-center justify-center rounded">
                                ECA
                              </div>
                            </div>
                            <div>
                              <div className="font-semibold">ECA</div>
                              <div className="text-sm text-gray-500 font-normal">Delivery Alliance</div>
                            </div>
                          </div>
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">Business Alliance</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Express Carriers Association - A Delivery Industry Alliance connecting shippers, carriers, and vendors for practical business networking and deal-making opportunities.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">MarketPlace Event: 48 business meetings in 48 hours</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Three-segment network: Shippers, Carriers, Vendors</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Working conference focused on actual deal-making</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Technology tools for member matching and networking</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Membership:</strong> $895/year with extensive member database access
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://ecadeliveryindustry.org', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit ECA
                        </Button>
                      </CardContent>
                    </Card>

                    {/* A4DD - Association for Delivery Drivers */}
                    <Card className="border-l-4 border-purple-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-12 h-12 rounded-lg overflow-hidden bg-white border-2 border-purple-200">
                              <div className="w-10 h-10 bg-gradient-to-r from-purple-600 to-violet-700 text-white font-bold text-xs flex items-center justify-center rounded">
                                A4DD
                              </div>
                            </div>
                            <div>
                              <div className="font-semibold">A4DD</div>
                              <div className="text-sm text-gray-500 font-normal">Driver Benefits</div>
                            </div>
                          </div>
                          <Badge variant="secondary" className="bg-purple-100 text-purple-800">Driver Benefits</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Association for Delivery Drivers - Non-profit providing insurance, training, and discounts exclusively for independent delivery drivers since 2007.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">Occupational accident & liability insurance</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Fuel cards, equipment, and healthcare discounts</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Safety training & certification courses</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Job board access and professional development</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Membership:</strong> $69/year (~$1.33/week) with US and Canada coverage
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.a4dd.org', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit A4DD
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Women in Trucking (WIT) */}
                    <Card className="border-l-4 border-pink-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-12 h-12 rounded-lg overflow-hidden bg-white border-2 border-pink-200">
                              <img 
                                src="https://www.womenintrucking.org/hs-fs/hubfs/images/logos/WIT%20Logos/WIT-logo-highres.png?width=200&height=60&name=WIT-logo-highres.png" 
                                alt="Women in Trucking"
                                className="w-11 h-auto object-contain"
                              />
                            </div>
                            <div>
                              <div className="font-semibold">Women in Trucking</div>
                              <div className="text-sm text-gray-500 font-normal">WIT - Est. 2007</div>
                            </div>
                          </div>
                          <Badge variant="secondary" className="bg-pink-100 text-pink-800">Professional Development</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          WIT promotes women's employment in transportation with mentorship, professional development, and advocacy. 5,500+ members across US and Canada.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">Mentor Match program for career development</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Annual Accelerate! Conference & Expo</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Professional recognition and awards programs</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Scholarships through WIT Foundation</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Founded:</strong> 2007 - Supporting diversity and inclusion in transportation
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.womenintrucking.org', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit WIT
                        </Button>
                      </CardContent>
                    </Card>

                    {/* OOIDA - Owner-Operator Independent Drivers Association */}
                    <Card className="border-l-4 border-red-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-12 h-12 rounded-lg overflow-hidden bg-white border-2 border-red-200">
                              <img 
                                src="https://www.ooida.com/wp-content/uploads/2016/01/header-logo.png" 
                                alt="OOIDA"
                                className="w-11 h-auto object-contain"
                              />
                            </div>
                            <div>
                              <div className="font-semibold">OOIDA</div>
                              <div className="text-sm text-gray-500 font-normal">Est. 1973</div>
                            </div>
                          </div>
                          <Badge variant="secondary" className="bg-red-100 text-red-800">Driver Advocacy</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Owner-Operator Independent Drivers Association - The voice of 150,000+ independent owner-operators and professional drivers since 1973.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">Legislative advocacy and regulatory reform</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Commercial truck insurance programs</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Business education and legal support</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Land Line Magazine and CDL protection</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Members:</strong> 150,000+ independent drivers with monthly payment plans available
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://www.ooida.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit OOIDA
                        </Button>
                      </CardContent>
                    </Card>

                    {/* Integrity Medical Courier Training */}
                    <Card className="border-l-4 border-teal-400">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-12 h-12 rounded-lg overflow-hidden bg-white border-2 border-teal-200">
                              <img 
                                src="https://integritydelivers.com/wp-content/uploads/2024/03/integrity_logo_horz_web.png" 
                                alt="Integrity Medical Courier Training"
                                className="w-11 h-auto object-contain"
                              />
                            </div>
                            <div>
                              <div className="font-semibold">Integrity Medical Courier Training</div>
                              <div className="text-sm text-gray-500 font-normal">Est. 2004</div>
                            </div>
                          </div>
                          <Badge variant="secondary" className="bg-teal-100 text-teal-800">Medical Training</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-4">
                          Leading medical courier training provider offering OSHA Bloodborne Pathogen, HIPAA compliance, and specialized courses for healthcare specimen handling and transportation.
                        </p>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-green-500"></div>
                            <span className="text-sm font-medium">Bloodborne Pathogen & HIPAA certification courses</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-sm font-medium">Hazardous drugs & chemotherapy transportation training</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
                            <span className="text-sm font-medium">Live webinars, on-site training, and online courses 24/7</span>
                          </div>
                          <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg">
                            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                            <span className="text-sm font-medium">Business startup guidance and compliance consulting</span>
                          </div>
                          <div className="p-3 bg-gray-50 rounded-lg border">
                            <p className="text-sm text-gray-600">
                              <strong>Experience:</strong> 40+ years healthcare experience, 40,000+ successful students trained
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-4"
                          onClick={() => window.open('https://integritydelivers.com', '_blank')}
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Visit Integrity Medical Courier Training
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            ) : (
              // Other categories placeholder
              <div className="bg-white/70 backdrop-blur-sm rounded-xl border border-gray-200/50 p-8">
                <div className="text-center py-12">
                  <div className={`inline-flex p-4 rounded-full bg-gradient-to-r ${getGradientClasses(selectedCategoryData?.color || 'gray')} mb-4`}>
                    {selectedCategoryData && <selectedCategoryData.icon className="w-8 h-8 text-white" />}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">
                    {selectedCategoryData?.name} Resources
                  </h3>
                  <p className="text-gray-600 max-w-md mx-auto">
                    Detailed content for {selectedCategoryData?.name.toLowerCase()} will be displayed here with the same modern, clean design.
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}