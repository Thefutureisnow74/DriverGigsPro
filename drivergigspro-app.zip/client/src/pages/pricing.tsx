import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Star, Zap, Crown, Infinity } from "lucide-react";

const plans = [
  {
    name: "Lifetime Access",
    price: "$495",
    period: "one time",
    description: "Everything forever - no monthly fees",
    icon: Infinity,
    gradient: "from-purple-600 to-pink-600",
    popular: true,
    features: [
      "Access to HUNDREDS of Driver Opportunities",
      "Complete Fleet Management System",
      "Advanced Job Tracking & Analytics",
      "Driver Gigs Academy & Training Courses",
      "Business Formation Tools & Guides",
      "Document Management & Storage",
      "Expense Tracking & Tax Optimization",
      "Calendar Integration & Scheduling",
      "Personal Coaching & Success Consultations",
      "Affiliate Program & Referral System",
      "Money For You AI Savings Recommendations",
      "Priority Feature Requests",
      "Exclusive Community Access",
      "No Monthly Fees - Pay Once, Own Forever"
    ]
  }
];

export default function Pricing() {
  return (
    <div>
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 p-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-800">Lifetime Access Plan</h1>
          <p className="text-gray-600 mt-2">Get everything you need for gig work success - pay once, own forever</p>
        </div>
      </header>

      {/* Pricing Content */}
      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          {/* Single Plan Card */}
          <div className="flex justify-center">
            <div className="w-full max-w-2xl">
              {plans.map((plan, index) => {
                const Icon = plan.icon;
                
                return (
                  <Card 
                    key={index}
                    className="card-hover relative overflow-hidden ring-2 ring-purple-500 shadow-2xl"
                  >
                    <div className="absolute top-0 left-0 right-0">
                      <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-center py-2 text-sm font-semibold">
                        ✨ Best Value - Limited Time
                      </div>
                    </div>
                    
                    <CardHeader className="text-center pt-12">
                      <div className="w-20 h-20 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-4 animate-float">
                        <Icon className="text-white text-3xl" />
                      </div>
                      
                      <CardTitle className="text-3xl font-bold text-gray-800">
                        {plan.name}
                      </CardTitle>
                      
                      <div className="mt-4">
                        <span className="text-5xl font-bold text-gray-900">{plan.price}</span>
                        <span className="text-gray-600 ml-2 text-lg">/{plan.period}</span>
                      </div>
                      
                      <p className="text-gray-600 mt-2 text-lg">{plan.description}</p>
                    </CardHeader>
                    
                    <CardContent className="px-6 pb-6">
                      <ul className="space-y-3 mb-8">
                        {plan.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-center space-x-3">
                            <div className="w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
                              <Check className="text-white w-3 h-3" />
                            </div>
                            <span className="text-gray-700">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      
                      <Button 
                        className="w-full py-6 text-lg font-semibold transition-all duration-300 bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-xl hover:scale-105"
                      >
                        Get Lifetime Access Now
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* FAQ Section */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">
              Frequently Asked Questions
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <Card className="card-hover">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-800 mb-2">Can I change plans anytime?</h3>
                  <p className="text-gray-600">Yes! You can upgrade, downgrade, or cancel your subscription at any time. Changes take effect immediately.</p>
                </CardContent>
              </Card>
              
              <Card className="card-hover">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-800 mb-2">Is there a free trial?</h3>
                  <p className="text-gray-600">Our Free plan is available forever! Try Pro features with a 14-day free trial, no credit card required.</p>
                </CardContent>
              </Card>
              
              <Card className="card-hover">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-800 mb-2">What payment methods do you accept?</h3>
                  <p className="text-gray-600">We accept all major credit cards, PayPal, and bank transfers for Enterprise plans.</p>
                </CardContent>
              </Card>
              
              <Card className="card-hover">
                <CardContent className="p-6">
                  <h3 className="font-semibold text-gray-800 mb-2">Do you offer refunds?</h3>
                  <p className="text-gray-600">Yes! We offer a 30-day money-back guarantee for all paid plans, no questions asked.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-16 text-center">
            <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
              <CardContent className="p-12">
                <h2 className="text-3xl font-bold mb-4">Ready to boost your gig work income?</h2>
                <p className="text-xl mb-8 opacity-90">Join thousands of drivers already using our platform</p>
                <Button className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold">
                  Start Your Free Trial
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
