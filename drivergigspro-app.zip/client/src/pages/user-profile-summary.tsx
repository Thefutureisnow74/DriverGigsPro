import { useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useLocation, Link } from "wouter";
import DocumentUpload from "@/components/document-upload";
import { FileAttachment } from "@/components/FileAttachment";
import { useState, useRef, useEffect } from "react";
import { 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  Car, 
  Building, 
  FileText, 
  DollarSign,
  Clock,
  CheckCircle,
  Target,
  Briefcase,
  Shield,
  CreditCard,
  Download,
  Upload,
  Building2,
  Eye,
  TrendingUp,
  Search,
  MoreHorizontal,
  ChevronUp,
  AlertTriangle,
  Send,
  MessageSquare,
  AlertCircle,
  Settings,
  Camera,
  X
} from "lucide-react";

export default function UserProfileSummary() {
  const [, setLocation] = useLocation();
  const [showCompanyModal, setShowCompanyModal] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('');
  const [modalTitle, setModalTitle] = useState('');
  
  // Chat state
  const [inputMessage, setInputMessage] = useState('');
  const [viewMode, setViewMode] = useState<'user' | 'assistant'>('user');
  const [assistantApiKey, setAssistantApiKey] = useState('');
  const [isAssistantAuthenticated, setIsAssistantAuthenticated] = useState(false);
  const [assistantInfo, setAssistantInfo] = useState<any>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const [messageAttachments, setMessageAttachments] = useState<{[messageId: number]: any[]}>({});
  const [lastSentMessageId, setLastSentMessageId] = useState<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Questionnaire state
  const [questionnaire, setQuestionnaire] = useState({
    primaryGoal: '',
    incomeTarget: '',
    schedulePreferences: [] as string[],
    industryInterests: [] as string[],
    vehicleTypes: [] as string[],
    distancePreference: ''
  });

  // Fetch messages from the database
  const { data: messages = [] } = useQuery<any[]>({
    queryKey: ['/api/assistant-messages'],
    staleTime: 30 * 1000 // Refresh every 30 seconds
  });

  // Auto scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Fetch attachments for each message
  useEffect(() => {
    const fetchAttachmentsForMessages = async () => {
      if (!messages || messages.length === 0) return;
      
      const attachmentPromises = messages.map(async (message) => {
        try {
          const response = await fetch(`/api/assistant-messages/${message.id}/attachments`);
          if (response.ok) {
            const attachments = await response.json();
            return { messageId: message.id, attachments };
          }
        } catch (error) {
          console.error(`Error fetching attachments for message ${message.id}:`, error);
        }
        return { messageId: message.id, attachments: [] };
      });

      const results = await Promise.all(attachmentPromises);
      const attachmentMap = {};
      results.forEach(({ messageId, attachments }) => {
        attachmentMap[messageId] = attachments;
      });
      setMessageAttachments(attachmentMap);
    };

    fetchAttachmentsForMessages();
  }, [messages]);

  // Function to show company modal instead of navigation
  const showCompaniesModal = (filter: string, title: string) => {
    setSelectedFilter(filter);
    setModalTitle(title);
    setShowCompanyModal(true);
  };



  // Handle assistant authentication
  const handleAssistantAuth = async () => {
    if (!assistantApiKey.trim()) return;
    
    try {
      const response = await fetch('/api/assistant/authenticate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          apiKey: assistantApiKey
        })
      });

      if (response.ok) {
        const data = await response.json();
        setIsAssistantAuthenticated(true);
        setAssistantInfo(data.assistant);
        localStorage.setItem('assistantSessionToken', data.sessionToken);
      } else {
        alert('Invalid API key. Please check your credentials.');
      }
    } catch (error) {
      console.error('Error authenticating assistant:', error);
      alert('Authentication failed. Please try again.');
    }
  };

  // Handle sending chat messages
  const handleSendMessage = async () => {
    if (inputMessage.trim()) {
      // Check if assistant needs authentication
      if (viewMode === 'assistant' && !isAssistantAuthenticated) {
        alert('Please authenticate with your Assistant API key first.');
        return;
      }

      try {
        const requestBody: any = {
          message: inputMessage,
          sender: viewMode
        };

        // Include API key for assistant messages
        if (viewMode === 'assistant') {
          requestBody.assistantApiKey = assistantApiKey;
        }

        const response = await fetch('/api/assistant-messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody)
        });

        if (response.ok) {
          const savedMessage = await response.json();
          setInputMessage('');
          setLastSentMessageId(savedMessage.id);
          // Refresh messages by invalidating the query
          queryClient.invalidateQueries({ queryKey: ['/api/assistant-messages'] });
        } else {
          const errorData = await response.json();
          alert(errorData.message || 'Failed to send message');
        }
      } catch (error) {
        console.error('Error sending message:', error);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // Save questionnaire responses
  const handleSaveQuestionnaire = async () => {
    try {
      const response = await fetch('/api/user/profile', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
          gigGoals: JSON.stringify(questionnaire)
        })
      });

      if (response.ok) {
        // Show success message
        alert('Your goals and preferences have been saved successfully!');
        // Refresh user data
        queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
      } else {
        alert('Failed to save preferences. Please try again.');
      }
    } catch (error) {
      console.error('Error saving questionnaire:', error);
      alert('An error occurred while saving. Please try again.');
    }
  };

  // Handle radio button changes
  const handleRadioChange = (name: string, value: string) => {
    setQuestionnaire(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle checkbox changes
  const handleCheckboxChange = (name: string, value: string) => {
    setQuestionnaire(prev => ({
      ...prev,
      [name]: prev[name as keyof typeof prev].includes(value)
        ? (prev[name as keyof typeof prev] as string[]).filter(item => item !== value)
        : [...(prev[name as keyof typeof prev] as string[]), value]
    }));
  };

  // Fetch all user-related data
  const { data: user } = useQuery<any>({
    queryKey: ["/api/user/profile"],
  });

  const { data: vehicles } = useQuery<any[]>({
    queryKey: ["/api/vehicles"],
  });

  const { data: companies } = useQuery<any[]>({
    queryKey: ["/api/companies"],
  });

  const { data: applications } = useQuery<any[]>({
    queryKey: ["/api/applications"],
  });

  const { data: userStats } = useQuery<any>({
    queryKey: ["/api/user/stats"],
  });

  const { data: companyActions } = useQuery<any[]>({
    queryKey: ["/api/company-actions"],
  });

  const { data: businessEntities } = useQuery<any[]>({
    queryKey: ["/api/business-entities"],
  });

  const { data: documents } = useQuery<any[]>({
    queryKey: ["/api/documents"],
  });

  const { data: expenses } = useQuery<any[]>({
    queryKey: ["/api/expenses"],
  });

  const { data: reminders } = useQuery<any[]>({
    queryKey: ["/api/reminders"],
  });

  // Load questionnaire data from user profile
  useEffect(() => {
    if (user?.gigGoals) {
      try {
        const savedQuestionnaire = JSON.parse(user.gigGoals);
        setQuestionnaire({
          primaryGoal: savedQuestionnaire.primaryGoal || '',
          incomeTarget: savedQuestionnaire.incomeTarget || '',
          schedulePreferences: savedQuestionnaire.schedulePreferences || [],
          industryInterests: savedQuestionnaire.industryInterests || [],
          vehicleTypes: savedQuestionnaire.vehicleTypes || [],
          distancePreference: savedQuestionnaire.distancePreference || ''
        });
      } catch (error) {
        console.error('Error parsing saved questionnaire data:', error);
      }
    }
  }, [user]);

  // Define primary vehicle from vehicles data
  const primaryVehicle = vehicles?.[0];
  
  // Fetch vehicle documents for primary vehicle photos
  const { data: vehicleDocuments } = useQuery({
    queryKey: [`/api/vehicles/${primaryVehicle?.id}/documents`],
    enabled: !!primaryVehicle?.id,
  });

  if (!user) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
          <p className="mt-4 text-gray-600">Loading profile data...</p>
        </div>
      </div>
    );
  }

  const getInitials = (name: string | undefined | null) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  // Calculate company counts using the same logic as Driver Opportunities page
  const getCompanyActionCounts = () => {
    if (!companyActions || !Array.isArray(companyActions)) {
      return {
        active: 0,
        applied: 0,
        research: 0,
        waitinglist: 0,
        other: 0,
        newOpportunities: 0
      };
    }

    // Create actions map for quick lookup
    const actionsMap: Record<number, string> = {};
    companyActions.forEach((action: any) => {
      actionsMap[action.companyId] = action.action;
    });

    // Count by action type
    const counts = {
      active: 0,
      applied: 0,
      research: 0,
      waitinglist: 0,
      other: 0,
      newOpportunities: 0
    };

    companyActions.forEach((action: any) => {
      console.log('Processing action:', action.action, 'for company:', action.companyId);
      switch (action.action) {
        case 'active':
          counts.active++;
          break;
        case 'apply':  // Companies page uses 'apply', not 'applied'
          counts.applied++;
          break;
        case 'research':
          counts.research++;
          break;
        case 'waitinglist':
          counts.waitinglist++;
          break;
        case 'other':
          counts.other++;
          break;
      }
    });
    
    console.log('Final counts:', counts);

    // Calculate new opportunities (companies added in last 24 hours)
    if (companies && Array.isArray(companies)) {
      const now = new Date();
      const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      
      const newCompanies = companies.filter((company: any) => {
        const createdAt = new Date(company.createdAt || company.dateAdded);
        return createdAt > yesterday;
      });
      
      counts.newOpportunities = newCompanies.length;
    }

    return counts;
  };

  // Use the same filtering logic as the modal for consistent counts
  const companyCounts = {
    active: companies && companyActions ? getFilteredCompanies(companies, companyActions, 'active').length : 0,
    applied: companies && companyActions ? getFilteredCompanies(companies, companyActions, 'apply').length : 0,
    research: companies && companyActions ? getFilteredCompanies(companies, companyActions, 'research').length : 0,
    waitinglist: companies && companyActions ? getFilteredCompanies(companies, companyActions, 'waitinglist').length : 0,
    other: companies && companyActions ? getFilteredCompanies(companies, companyActions, 'other').length : 0,
    newOpportunities: companies && companyActions ? getFilteredCompanies(companies, companyActions, 'newOpportunities').length : 0
  };
  
  // Keep the old variables for backward compatibility
  const activeCompanies = companyActions?.filter(action => action.action === 'active') || [];
  const appliedCompanies = companyActions?.filter(action => action.action === 'applied') || [];
  const researchingCompanies = companyActions?.filter(action => action.action === 'research') || [];

  // Calculate vehicle alerts
  const getVehicleAlerts = (): number => {
    if (!vehicles || !Array.isArray(vehicles) || vehicles.length === 0) return 0;
    
    const today = new Date();
    let alertCount = 0;

    vehicles.forEach((vehicle: any) => {
      // Check insurance expiry
      if (vehicle.insuranceExpiry) {
        const expiryDate = new Date(vehicle.insuranceExpiry);
        const daysLeft = Math.ceil((expiryDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysLeft <= 30) {
          alertCount++;
        }
      }

      // Check registration expiry
      if (vehicle.registrationExpiry) {
        const regDate = new Date(vehicle.registrationExpiry);
        const daysLeft = Math.ceil((regDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysLeft <= 30) {
          alertCount++;
        }
      }
    });

    return alertCount;
  };

  const vehicleAlertCount = getVehicleAlerts();

  const exportProfile = () => {
    const profileData = {
      personalInfo: {
        fullName: user.fullName,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        address: user.address,
        city: user.city,
        state: user.state,
        zipCode: user.zipCode,
        dateOfBirth: user.dateOfBirth,
        bio: user.bio
      },
      vehicleInfo: primaryVehicle ? {
        nickname: primaryVehicle.nickname,
        year: primaryVehicle.year,
        make: primaryVehicle.make,
        model: primaryVehicle.model,
        vehicleType: primaryVehicle.vehicleType,
        color: primaryVehicle.color,
        vin: primaryVehicle.vin,
        licensePlate: primaryVehicle.licensePlate,
        mileage: primaryVehicle.mileage,
        fuelType: primaryVehicle.fuelType,
        mpg: primaryVehicle.mpg,
        insuranceExpiry: primaryVehicle.insuranceExpiry,
        insuranceCompanyName: primaryVehicle.insuranceCompanyName,
        insurancePolicyNumber: primaryVehicle.insurancePolicyNumber
      } : null,
      workStatus: {
        activeJobs: userStats?.activeJobs || 0,
        totalApplications: userStats?.totalApplications || 0,
        totalCompanies: companies?.length || 0,
        activeCompanies: activeCompanies.length,
        appliedCompanies: appliedCompanies.length,
        researchingCompanies: researchingCompanies.length
      },
      businessInfo: businessEntities?.[0] || null,
      documents: documents?.length || 0,
      expenses: expenses?.length || 0,
      reminders: reminders?.length || 0
    };

    const dataStr = JSON.stringify(profileData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `${user.firstName || 'User'}_${user.lastName || 'Profile'}_Profile_${new Date().toISOString().split('T')[0]}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={user.profileImageUrl || "/api/placeholder/80/80"} />
                  <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-600 text-white text-xl">
                    {getInitials(user.fullName)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">{user.fullName || 'User Profile'}</h1>
                  <p className="text-lg text-gray-600">Professional Driver Profile</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <Badge variant="outline" className="bg-green-100 text-green-700 border-green-300">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Verified Profile
                    </Badge>
                    <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-300">
                      Member since {new Date(user.createdAt).toLocaleDateString()}
                    </Badge>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>

        {/* Dashboard Company Status Tabs */}
        <div className="mb-6">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
            {/* Active Companies */}
            <Card 
              className="border border-slate-200 shadow-sm bg-white hover:shadow-md hover:border-slate-300 transition-all duration-300 group overflow-hidden cursor-pointer hover:-translate-y-1"
              onClick={() => showCompaniesModal('active', 'Active Companies')}
            >
              <CardContent className="p-2 relative">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-blue-500 to-blue-600 group-hover:w-2 transition-all duration-300"></div>
                <div className="relative flex items-center gap-2">
                  <div className="p-1 bg-gradient-to-r from-blue-500 to-blue-600 shadow-sm rounded">
                    <Building2 className="w-3 h-3 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-500 tracking-wider uppercase truncate">ACTIVE COMPANIES</p>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-lg font-black text-slate-800 tracking-tight">
                        {companyCounts.active}
                      </h3>
                      <span className="inline-flex items-center px-1 py-0.5 text-xs font-bold text-green-600 bg-green-100 border rounded">
                        <ChevronUp className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Researching */}
            <Card 
              className="border border-slate-200 shadow-sm bg-white hover:shadow-md hover:border-slate-300 transition-all duration-300 group overflow-hidden cursor-pointer hover:-translate-y-1"
              onClick={() => showCompaniesModal('research', 'Researching Companies')}
            >
              <CardContent className="p-2 relative">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-orange-500 to-orange-600 group-hover:w-2 transition-all duration-300"></div>
                <div className="relative flex items-center gap-2">
                  <div className="p-1 bg-gradient-to-r from-orange-500 to-orange-600 shadow-sm rounded">
                    <Search className="w-3 h-3 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-500 tracking-wider uppercase truncate">RESEARCHING</p>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-lg font-black text-slate-800 tracking-tight">
                        {companyCounts.research}
                      </h3>
                      <span className="inline-flex items-center px-1 py-0.5 text-xs font-bold text-blue-600 bg-blue-100 border rounded">
                        <TrendingUp className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Applied */}
            <Card 
              className="border border-slate-200 shadow-sm bg-white hover:shadow-md hover:border-slate-300 transition-all duration-300 group overflow-hidden cursor-pointer hover:-translate-y-1"
              onClick={() => showCompaniesModal('applied', 'Applied Companies')}
            >
              <CardContent className="p-2 relative">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-green-500 to-green-600 group-hover:w-2 transition-all duration-300"></div>
                <div className="relative flex items-center gap-2">
                  <div className="p-1 bg-gradient-to-r from-green-500 to-green-600 shadow-sm rounded">
                    <CheckCircle className="w-3 h-3 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-500 tracking-wider uppercase truncate">APPLIED</p>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-lg font-black text-slate-800 tracking-tight">
                        {companyCounts.applied}
                      </h3>
                      <span className="inline-flex items-center px-1 py-0.5 text-xs font-bold text-green-600 bg-green-100 border rounded">
                        <ChevronUp className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Waiting List */}
            <Card 
              className="border border-slate-200 shadow-sm bg-white hover:shadow-md hover:border-slate-300 transition-all duration-300 group overflow-hidden cursor-pointer hover:-translate-y-1"
              onClick={() => showCompaniesModal('waitinglist', 'Waiting List Companies')}
            >
              <CardContent className="p-2 relative">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-yellow-500 to-yellow-600 group-hover:w-2 transition-all duration-300"></div>
                <div className="relative flex items-center gap-2">
                  <div className="p-1 bg-gradient-to-r from-yellow-500 to-yellow-600 shadow-sm rounded">
                    <Clock className="w-3 h-3 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-500 tracking-wider uppercase truncate">WAITING LIST</p>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-lg font-black text-slate-800 tracking-tight">
                        {companyCounts.waitinglist}
                      </h3>
                      <span className="inline-flex items-center px-1 py-0.5 text-xs font-bold text-blue-600 bg-blue-100 border rounded">
                        <TrendingUp className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Other */}
            <Card 
              className="border border-slate-200 shadow-sm bg-white hover:shadow-md hover:border-slate-300 transition-all duration-300 group overflow-hidden cursor-pointer hover:-translate-y-1"
              onClick={() => showCompaniesModal('other', 'Other Companies')}
            >
              <CardContent className="p-2 relative">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-gray-500 to-gray-600 group-hover:w-2 transition-all duration-300"></div>
                <div className="relative flex items-center gap-2">
                  <div className="p-1 bg-gradient-to-r from-gray-500 to-gray-600 shadow-sm rounded">
                    <MoreHorizontal className="w-3 h-3 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-500 tracking-wider uppercase truncate">OTHER</p>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-lg font-black text-slate-800 tracking-tight">
                        {companyCounts.other}
                      </h3>
                      <span className="inline-flex items-center px-1 py-0.5 text-xs font-bold text-green-600 bg-green-100 border rounded">
                        <ChevronUp className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* New Opportunities */}
            <Card 
              className="border border-slate-200 shadow-sm bg-white hover:shadow-md hover:border-slate-300 transition-all duration-300 group overflow-hidden cursor-pointer hover:-translate-y-1"
              onClick={() => showCompaniesModal('newOpportunities', 'New Opportunities')}
            >
              <CardContent className="p-2 relative">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-purple-500 to-purple-600 group-hover:w-2 transition-all duration-300"></div>
                <div className="relative flex items-center gap-2">
                  <div className="p-1 bg-gradient-to-r from-purple-500 to-purple-600 shadow-sm rounded">
                    <TrendingUp className="w-3 h-3 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-slate-500 tracking-wider uppercase truncate">NEW OPPORTUNITIES</p>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-lg font-black text-slate-800 tracking-tight">
                        {companyCounts.newOpportunities}
                      </h3>
                      <span className="inline-flex items-center px-1 py-0.5 text-xs font-bold text-green-600 bg-green-100 border rounded">
                        <ChevronUp className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="w-4 h-4" />
              <span>Profile Summary</span>
            </TabsTrigger>
            <TabsTrigger value="documents" className="flex items-center space-x-2">
              <Upload className="w-4 h-4" />
              <span>Gig Documents</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            {/* Communication Hub - Full Width at Top */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="w-5 h-5 mr-2 text-blue-600" />
                  Communication Hub
                </CardTitle>
                <CardDescription className="text-sm text-gray-600 break-words">
                  {viewMode === 'user' 
                    ? 'Send messages to your Personal Assistant' 
                    : 'Assistant responds to user messages'
                  }
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {/* View Mode Buttons */}
                <div className="p-4 border-b bg-gray-50">
                  <div className="flex items-center justify-center space-x-2">
                    <Button
                      variant={viewMode === 'user' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setViewMode('user')}
                    >
                      User View
                    </Button>
                    <Button
                      variant={viewMode === 'assistant' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setViewMode('assistant')}
                    >
                      Assistant View
                    </Button>
                  </div>
                </div>

                {/* Assistant Authentication */}
                {viewMode === 'assistant' && (
                  <div className="p-4 border-b bg-yellow-50">
                    {!isAssistantAuthenticated ? (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-amber-600" />
                          <span className="text-sm font-medium text-amber-800">Assistant Authentication Required</span>
                        </div>
                        <div className="flex space-x-2">
                          <Input
                            type="password"
                            value={assistantApiKey}
                            onChange={(e) => setAssistantApiKey(e.target.value)}
                            placeholder="Enter your Assistant API Key..."
                            className="flex-1 text-sm"
                          />
                          <Button 
                            onClick={handleAssistantAuth}
                            disabled={!assistantApiKey.trim()}
                            size="sm"
                            className="bg-amber-600 hover:bg-amber-700"
                          >
                            Authenticate
                          </Button>
                        </div>
                        <p className="text-xs text-amber-700">
                          Virtual assistants must authenticate with their API key to send messages securely.
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span className="text-sm font-medium text-green-800">
                            Authenticated as {assistantInfo?.name}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-xs text-green-700">
                            Location: {assistantInfo?.country || 'Not specified'}
                          </p>
                          <Button 
                            onClick={() => {
                              setIsAssistantAuthenticated(false);
                              setAssistantInfo(null);
                              setAssistantApiKey('');
                              localStorage.removeItem('assistantSessionToken');
                            }}
                            variant="outline"
                            size="sm"
                            className="text-xs h-6"
                          >
                            Logout
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
                
                {/* Messages Area */}
                <div className="h-[400px] flex flex-col">
                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div key={message.id} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[80%] rounded-lg p-3 ${
                            message.sender === 'user' 
                              ? 'bg-blue-500 text-white' 
                              : 'bg-gray-100 text-gray-900'
                          }`}>
                            <p className={`text-xs font-semibold mb-1 ${
                              message.sender === 'user' ? 'text-blue-100' : 'text-gray-600'
                            }`}>
                              {message.sender === 'user' ? 'User' : 'Assistant'}
                            </p>
                            <p className="text-sm whitespace-pre-line">{message.message || message.text}</p>
                            
                            {/* File Attachments */}
                            {messageAttachments[message.id] && messageAttachments[message.id].length > 0 && (
                              <div className="mt-2">
                                <FileAttachment 
                                  messageId={message.id}
                                  attachments={messageAttachments[message.id]}
                                  allowUpload={false}
                                />
                              </div>
                            )}
                            
                            <p className={`text-xs mt-1 ${
                              message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                            }`}>
                              {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  </ScrollArea>
                  
                  {/* Message Input */}
                  <div className="p-4 border-t bg-gray-50">
                    <div className="flex space-x-2">
                      <Input
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                        placeholder={viewMode === 'user' ? 'Type your message to assistant...' : 'Type response to user...'}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        className="flex-1"
                      />
                      <Button onClick={handleSendMessage} disabled={!inputMessage.trim()}>
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    {/* File Upload for Last Sent Message */}
                    {lastSentMessageId && (
                      <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-md">
                        <p className="text-sm text-blue-700 mb-2 font-medium">
                          Add attachments to your message:
                        </p>
                        <FileAttachment 
                          messageId={lastSentMessageId}
                          allowUpload={true}
                          onFileUploaded={(attachment) => {
                            // Refresh attachments for this message
                            queryClient.invalidateQueries({ queryKey: ['/api/assistant-messages'] });
                            // Update local attachment state
                            setMessageAttachments(prev => ({
                              ...prev,
                              [lastSentMessageId]: [...(prev[lastSentMessageId] || []), attachment]
                            }));
                          }}
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setLastSentMessageId(null)}
                          className="mt-2 text-xs"
                        >
                          <X className="w-3 h-3 mr-1" />
                          Done
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-6">
            {/* Personal Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="w-5 h-5 mr-2 text-blue-600" />
                  Personal Information
                </CardTitle>
                <CardDescription>Complete personal details for gig platform onboarding</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Basic Information */}
                <div>
                  <h4 className="font-semibold text-gray-800 mb-3 flex items-center">
                    <User className="w-4 h-4 mr-1" />
                    Basic Information
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center space-x-3">
                      <User className="w-4 h-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Full Legal Name</p>
                        <p className="font-medium">{(user.firstName && user.lastName) ? `${user.firstName} ${user.lastName}` : (user.fullName || 'Not provided')}</p>
                        <p className="text-xs text-gray-400">As shown on driver's license</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Date of Birth</p>
                        <p className="font-medium">{user.dateOfBirth ? new Date(user.dateOfBirth + 'T12:00:00').toLocaleDateString() : 'Not provided'}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Phone className="w-4 h-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Phone Number</p>
                        <p className="font-medium">{user.phone || 'Not provided'}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Mail className="w-4 h-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Email Address</p>
                        <p className="font-medium">{user.email || 'Not provided'}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 md:col-span-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Residential Address</p>
                        <p className="font-medium">{user.address || 'Not provided'}</p>
                        <p className="text-sm text-gray-600">{user.city || ''}, {user.state || ''} {user.zipCode || ''}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Shield className="w-4 h-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Social Security Number</p>
                        <p className="font-medium text-blue-600">Protected Information</p>
                        <p className="text-xs text-gray-400">Required for background check & tax reporting</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <AlertCircle className="w-4 h-4 text-gray-500" />
                      <div>
                        <p className="text-sm text-gray-500">Emergency Contact</p>
                        <p className="font-medium">Not provided</p>
                        <p className="text-xs text-gray-400">Optional but recommended for rideshare</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Shield className="w-4 h-4 text-purple-500" />
                      <div>
                        <p className="text-sm text-gray-500">DOT Number</p>
                        <p className="font-medium">{user.dotNumber || 'Not provided'}</p>
                        <p className="text-xs text-gray-400">Safety monitoring ID - Optional</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Building2 className="w-4 h-4 text-purple-500" />
                      <div>
                        <p className="text-sm text-gray-500">MC Number</p>
                        <p className="font-medium">{user.mcNumber || 'Not provided'}</p>
                        <p className="text-xs text-gray-400">Authority to operate as a for-hire carrier in interstate commerce - Optional</p>
                      </div>
                    </div>
                  </div>
                </div>


                <div className="border-t pt-6">
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg border border-blue-200">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                      <Target className="w-5 h-5 mr-2 text-blue-600" />
                      Your Gig Goals & Objectives
                    </h3>
                    
                    <div className="space-y-4">
                      {/* Question 1: Primary Goal */}
                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">What's your primary goal with gig work?</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="primary-goal" 
                              value="full-time-income" 
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('primaryGoal', e.target.value)}
                              checked={questionnaire.primaryGoal === 'full-time-income'}
                            />
                            <span className="text-sm">Full-time income replacement</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="primary-goal" 
                              value="part-time-income" 
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('primaryGoal', e.target.value)}
                              checked={questionnaire.primaryGoal === 'part-time-income'}
                            />
                            <span className="text-sm">Part-time supplemental income</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="primary-goal" 
                              value="flexible-schedule" 
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('primaryGoal', e.target.value)}
                              checked={questionnaire.primaryGoal === 'flexible-schedule'}
                            />
                            <span className="text-sm">Flexible schedule control</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="primary-goal" 
                              value="experience-industries" 
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('primaryGoal', e.target.value)}
                              checked={questionnaire.primaryGoal === 'experience-industries'}
                            />
                            <span className="text-sm">Experience different industries</span>
                          </label>
                        </div>
                      </div>

                      {/* Question 2: Income Target */}
                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">What's your target monthly income from gigs?</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="income-target" 
                              value="500-1500"
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('incomeTarget', e.target.value)}
                              checked={questionnaire.incomeTarget === '500-1500'}
                            />
                            <span className="text-sm">$500-$1,500</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="income-target" 
                              value="1500-3000"
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('incomeTarget', e.target.value)}
                              checked={questionnaire.incomeTarget === '1500-3000'}
                            />
                            <span className="text-sm">$1,500-$3,000</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="income-target" 
                              value="3000-5000"
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('incomeTarget', e.target.value)}
                              checked={questionnaire.incomeTarget === '3000-5000'}
                            />
                            <span className="text-sm">$3,000-$5,000</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="income-target" 
                              value="5000+"
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('incomeTarget', e.target.value)}
                              checked={questionnaire.incomeTarget === '5000+'}
                            />
                            <span className="text-sm">$5,000+</span>
                          </label>
                        </div>
                      </div>

                      {/* Question 3: Schedule Preference */}
                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">When do you prefer to work?</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="weekday-mornings"
                              onChange={(e) => handleCheckboxChange('schedulePreferences', e.target.value)}
                              checked={questionnaire.schedulePreferences.includes('weekday-mornings')}
                            />
                            <span className="text-sm">Weekday mornings (6AM-12PM)</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="weekday-afternoons"
                              onChange={(e) => handleCheckboxChange('schedulePreferences', e.target.value)}
                              checked={questionnaire.schedulePreferences.includes('weekday-afternoons')}
                            />
                            <span className="text-sm">Weekday afternoons (12PM-6PM)</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="weekday-evenings"
                              onChange={(e) => handleCheckboxChange('schedulePreferences', e.target.value)}
                              checked={questionnaire.schedulePreferences.includes('weekday-evenings')}
                            />
                            <span className="text-sm">Weekday evenings (6PM-12AM)</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="weekend-mornings"
                              onChange={(e) => handleCheckboxChange('schedulePreferences', e.target.value)}
                              checked={questionnaire.schedulePreferences.includes('weekend-mornings')}
                            />
                            <span className="text-sm">Weekend mornings</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="weekend-evenings"
                              onChange={(e) => handleCheckboxChange('schedulePreferences', e.target.value)}
                              checked={questionnaire.schedulePreferences.includes('weekend-evenings')}
                            />
                            <span className="text-sm">Weekend evenings</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="overnight-shifts"
                              onChange={(e) => handleCheckboxChange('schedulePreferences', e.target.value)}
                              checked={questionnaire.schedulePreferences.includes('overnight-shifts')}
                            />
                            <span className="text-sm">Overnight shifts</span>
                          </label>
                        </div>
                      </div>

                      {/* Question 4: Industry Preference */}
                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">Which industries interest you most?</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="food-delivery"
                              onChange={(e) => handleCheckboxChange('industryInterests', e.target.value)}
                              checked={questionnaire.industryInterests.includes('food-delivery')}
                            />
                            <span className="text-sm">🍔 Food Delivery</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600"
                              value="rideshare"
                              onChange={(e) => handleCheckboxChange('industryInterests', e.target.value)}
                              checked={questionnaire.industryInterests.includes('rideshare')}
                            />
                            <span className="text-sm">🚗 Rideshare Passenger Transport</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600"
                              value="package-delivery"
                              onChange={(e) => handleCheckboxChange('industryInterests', e.target.value)}
                              checked={questionnaire.industryInterests.includes('package-delivery')}
                            />
                            <span className="text-sm">📦 Package/Logistics Delivery</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600"
                              value="medical-transport"
                              onChange={(e) => handleCheckboxChange('industryInterests', e.target.value)}
                              checked={questionnaire.industryInterests.includes('medical-transport')}
                            />
                            <span className="text-sm">🏥 Medical Transport</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600"
                              value="senior-services"
                              onChange={(e) => handleCheckboxChange('industryInterests', e.target.value)}
                              checked={questionnaire.industryInterests.includes('senior-services')}
                            />
                            <span className="text-sm">🎓 Senior/Disability Services</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600"
                              value="corporate-services"
                              onChange={(e) => handleCheckboxChange('industryInterests', e.target.value)}
                              checked={questionnaire.industryInterests.includes('corporate-services')}
                            />
                            <span className="text-sm">💼 Corporate/Business Services</span>
                          </label>
                        </div>
                      </div>

                      {/* Question 5: Vehicle Types */}
                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">What vehicle types do you have available?</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="Car"
                              onChange={(e) => handleCheckboxChange('vehicleTypes', e.target.value)}
                              checked={questionnaire.vehicleTypes.includes('Car')}
                            />
                            <span className="text-sm">🚗 Car</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="SUV"
                              onChange={(e) => handleCheckboxChange('vehicleTypes', e.target.value)}
                              checked={questionnaire.vehicleTypes.includes('SUV')}
                            />
                            <span className="text-sm">🚙 SUV</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="Truck"
                              onChange={(e) => handleCheckboxChange('vehicleTypes', e.target.value)}
                              checked={questionnaire.vehicleTypes.includes('Truck')}
                            />
                            <span className="text-sm">🚚 Truck</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="Van"
                              onChange={(e) => handleCheckboxChange('vehicleTypes', e.target.value)}
                              checked={questionnaire.vehicleTypes.includes('Van')}
                            />
                            <span className="text-sm">🚐 Van</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="Motorcycle"
                              onChange={(e) => handleCheckboxChange('vehicleTypes', e.target.value)}
                              checked={questionnaire.vehicleTypes.includes('Motorcycle')}
                            />
                            <span className="text-sm">🏍️ Motorcycle</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="checkbox" 
                              className="text-blue-600" 
                              value="Bicycle"
                              onChange={(e) => handleCheckboxChange('vehicleTypes', e.target.value)}
                              checked={questionnaire.vehicleTypes.includes('Bicycle')}
                            />
                            <span className="text-sm">🚲 Bicycle</span>
                          </label>
                        </div>
                      </div>

                      {/* Question 6: Distance Preference */}
                      <div className="bg-white p-4 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">How far are you willing to travel for gigs?</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="distance-preference" 
                              value="10-miles"
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('distancePreference', e.target.value)}
                              checked={questionnaire.distancePreference === '10-miles'}
                            />
                            <span className="text-sm">Within 10 miles</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="distance-preference" 
                              value="25-miles"
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('distancePreference', e.target.value)}
                              checked={questionnaire.distancePreference === '25-miles'}
                            />
                            <span className="text-sm">Within 25 miles</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="distance-preference" 
                              value="50-miles"
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('distancePreference', e.target.value)}
                              checked={questionnaire.distancePreference === '50-miles'}
                            />
                            <span className="text-sm">Within 50 miles</span>
                          </label>
                          <label className="flex items-center space-x-2 cursor-pointer">
                            <input 
                              type="radio" 
                              name="distance-preference" 
                              value="statewide"
                              className="text-blue-600" 
                              onChange={(e) => handleRadioChange('distancePreference', e.target.value)}
                              checked={questionnaire.distancePreference === 'statewide'}
                            />
                            <span className="text-sm">Anywhere in state</span>
                          </label>
                        </div>
                      </div>

                      {/* Save Button */}
                      <div className="flex justify-center pt-4">
                        <Button 
                          onClick={handleSaveQuestionnaire}
                          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8"
                        >
                          <Target className="w-4 h-4 mr-2" />
                          Save My Goals & Preferences
                        </Button>
                      </div>

                      {/* Optional: Show saved bio if exists */}
                      {user.bio && (
                        <div className="mt-4 bg-white p-4 rounded-lg border-l-4 border-blue-500">
                          <h5 className="font-medium text-gray-900 mb-2">Previous Notes:</h5>
                          <p className="text-gray-700 text-sm italic">{user.bio}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>





            {/* Business Information */}
            {businessEntities && businessEntities.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Building2 className="w-5 h-5 mr-2 text-blue-600" />
                    Business Information
                  </CardTitle>
                  <CardDescription>Complete business profile from My Business</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {businessEntities.slice(0, 2).map((entity: any, index: number) => (
                      <div key={index} className="border rounded-lg p-6 bg-gradient-to-br from-blue-50 to-indigo-50">
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex-1">
                            <h3 className="text-xl font-bold text-gray-900 mb-2">{entity.companyName || entity.businessName}</h3>
                            <div className="flex items-center space-x-4 text-sm">
                              <Badge variant={entity.status === 'Active' ? 'default' : 'secondary'}>
                                {entity.status}
                              </Badge>
                              <span className="text-gray-600">{entity.businessType || entity.entityType}</span>
                              <span className="text-gray-600">{entity.stateOfOrganization || entity.state}</span>
                            </div>
                          </div>
                        </div>

                        {/* Business Details Grid */}
                        <div className="grid md:grid-cols-2 gap-6">
                          {/* Left Column */}
                          <div className="space-y-4">
                            {/* Business Address */}
                            {entity.companyAddress && (
                              <div className="flex items-start space-x-3">
                                <MapPin className="w-5 h-5 text-gray-500 mt-1 flex-shrink-0" />
                                <div>
                                  <p className="font-medium text-gray-700">Business Address</p>
                                  <p className="text-sm text-gray-600">{entity.companyAddress}</p>
                                  {entity.registeredAgentCity && entity.registeredAgentState && (
                                    <p className="text-sm text-gray-600">{entity.registeredAgentCity}, {entity.registeredAgentState} {entity.registeredAgentZipCode}</p>
                                  )}
                                </div>
                              </div>
                            )}

                            {/* Contact Information */}
                            <div className="space-y-3">
                              {entity.companyPhone && (
                                <div className="flex items-center space-x-3">
                                  <Phone className="w-5 h-5 text-gray-500 flex-shrink-0" />
                                  <div>
                                    <p className="font-medium text-gray-700">Phone</p>
                                    <p className="text-sm text-gray-600">{entity.companyPhone}</p>
                                  </div>
                                </div>
                              )}

                              {entity.email && (
                                <div className="flex items-center space-x-3">
                                  <Mail className="w-5 h-5 text-gray-500 flex-shrink-0" />
                                  <div>
                                    <p className="font-medium text-gray-700">Email</p>
                                    <p className="text-sm text-gray-600">{entity.email}</p>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Right Column */}
                          <div className="space-y-4">
                            {/* Business Registration */}
                            <div className="bg-white rounded-lg p-4 border">
                              <h4 className="font-medium text-gray-700 mb-3 flex items-center">
                                <Shield className="w-4 h-4 mr-2 text-green-600" />
                                Registration Details
                              </h4>
                              <div className="space-y-2">
                                {entity.ein && (
                                  <div className="flex justify-between">
                                    <span className="text-sm text-gray-600">EIN:</span>
                                    <span className="text-sm font-medium">{entity.ein}</span>
                                  </div>
                                )}
                                {entity.sosFileNumber && (
                                  <div className="flex justify-between">
                                    <span className="text-sm text-gray-600">SOS File #:</span>
                                    <span className="text-sm font-medium">{entity.sosFileNumber}</span>
                                  </div>
                                )}
                                {entity.formationDate && (
                                  <div className="flex justify-between">
                                    <span className="text-sm text-gray-600">Formation:</span>
                                    <span className="text-sm font-medium">{new Date(entity.formationDate).toLocaleDateString()}</span>
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Registered Agent */}
                            {entity.registeredAgent && (
                              <div className="bg-white rounded-lg p-4 border">
                                <h4 className="font-medium text-gray-700 mb-3 flex items-center">
                                  <User className="w-4 h-4 mr-2 text-purple-600" />
                                  Registered Agent
                                </h4>
                                <div className="space-y-2">
                                  <p className="text-sm font-medium">{entity.registeredAgent}</p>
                                  {entity.registeredAgentAddress && (
                                    <p className="text-xs text-gray-600">{entity.registeredAgentAddress}</p>
                                  )}
                                  {entity.registeredAgentPhone && (
                                    <p className="text-xs text-gray-600">{entity.registeredAgentPhone}</p>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Website and Additional Info */}
                        {(entity.website || entity.websiteUrl) && (
                          <div className="mt-4 pt-4 border-t">
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                                <span className="text-blue-600 text-sm font-bold">W</span>
                              </div>
                              <div>
                                <p className="font-medium text-gray-700">Website</p>
                                <a 
                                  href={entity.website || entity.websiteUrl} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-sm text-blue-600 hover:underline"
                                >
                                  {entity.website || entity.websiteUrl}
                                </a>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Primary Vehicle Information */}
            {primaryVehicle && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Car className="w-5 h-5 mr-2 text-blue-600" />
                    Primary Vehicle - "{primaryVehicle.nickname}"
                  </CardTitle>
                  <CardDescription>Vehicle details and specifications</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-gray-500">Vehicle Details</p>
                        <p className="font-medium">{primaryVehicle.year} {primaryVehicle.make} {primaryVehicle.model}</p>
                        <p className="text-sm text-gray-600">{primaryVehicle.vehicleType} • {primaryVehicle.color}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">License Plate</p>
                        <p className="font-medium">{primaryVehicle.licensePlate} ({primaryVehicle.state})</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-gray-500">Mileage & Fuel</p>
                        <p className="font-medium">{primaryVehicle.mileage?.toLocaleString()} miles</p>
                        <p className="text-sm text-gray-600">{primaryVehicle.fuelType} • {primaryVehicle.mpg} MPG</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">VIN</p>
                        <p className="font-medium text-xs">{primaryVehicle.vin}</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-gray-500">Insurance</p>
                        <p className="font-medium text-sm">{primaryVehicle.insuranceCompanyName}</p>
                        <p className="text-sm text-gray-600">Policy: {primaryVehicle.insurancePolicyNumber}</p>
                        <p className="text-sm text-gray-600">Expires: {primaryVehicle.insuranceExpiry ? new Date(primaryVehicle.insuranceExpiry).toLocaleDateString() : 'Not set'}</p>
                      </div>
                    </div>
                  </div>

                  {/* Vehicle Photos Section - From My Fleet */}
                  {(() => {
                    // Filter vehicle documents for photos/images
                    const photoDocuments = vehicleDocuments?.filter((doc: any) => 
                      doc.documentCategory === 'Vehicle Photos' || 
                      doc.fileName?.match(/\.(jpg|jpeg|png|gif|webp)$/i) ||
                      doc.originalName?.match(/\.(jpg|jpeg|png|gif|webp)$/i)
                    ) || [];
                    
                    // Download function for photos
                    const downloadPhoto = async (documentId: number, filename: string) => {
                      try {
                        const response = await fetch(`/api/vehicles/documents/${documentId}/download`, {
                          credentials: 'include'
                        });
                        if (!response.ok) throw new Error('Download failed');
                        const blob = await response.blob();
                        const url = window.URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = url;
                        link.download = filename;
                        document.body.appendChild(link);
                        link.click();
                        window.URL.revokeObjectURL(url);
                        document.body.removeChild(link);
                      } catch (error) {
                        console.error('Download failed:', error);
                      }
                    };

                    return photoDocuments.length > 0 ? (
                      <div className="mt-6">
                        <div className="mb-3">
                          <p className="text-sm font-medium text-gray-700 flex items-center">
                            <Camera className="w-4 h-4 mr-2 text-blue-600" />
                            Vehicle Photos (My Fleet)
                          </p>
                          <p className="text-xs text-gray-500">Photos of {primaryVehicle.nickname || 'your vehicle'} from My Fleet section</p>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          {photoDocuments.slice(0, 8).map((doc: any, index: number) => (
                            <div key={doc.id} className="relative group">
                              <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden border-2 border-gray-200 hover:border-blue-300 transition-colors cursor-pointer">
                                <img 
                                  src={`/api/vehicles/documents/${doc.id}/download`} 
                                  alt={`${primaryVehicle.nickname || 'Vehicle'} - ${doc.originalName || doc.fileName}`}
                                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                                  onClick={() => setSelectedPhoto(`/api/vehicles/documents/${doc.id}/download`)}
                                />
                              </div>
                              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-200 rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100">
                                <div className="flex space-x-2">
                                  <Button
                                    size="sm"
                                    variant="secondary"
                                    className="text-xs h-6 px-2"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setSelectedPhoto(`/api/vehicles/documents/${doc.id}/download`);
                                    }}
                                  >
                                    View
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="secondary"
                                    className="text-xs h-6 px-2"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      downloadPhoto(doc.id, doc.originalName || doc.fileName);
                                    }}
                                  >
                                    <Download className="w-3 h-3" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        {photoDocuments.length > 8 && (
                          <p className="text-xs text-gray-500 mt-2">
                            Showing 8 of {photoDocuments.length} photos • <Link href="/my-fleet" className="text-blue-600 hover:underline">Manage in My Fleet</Link>
                          </p>
                        )}

                        {/* Photo Viewer Modal */}
                        {selectedPhoto && (
                          <Dialog open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
                            <DialogContent className="max-w-4xl max-h-[90vh] p-4">
                              <DialogHeader>
                                <DialogTitle className="flex items-center justify-between">
                                  <span>Vehicle Photo - {primaryVehicle.nickname}</span>
                                  <div className="flex space-x-2">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => {
                                        const selectedDoc = photoDocuments.find((doc: any) => `/api/vehicles/documents/${doc.id}/download` === selectedPhoto);
                                        if (selectedDoc) downloadPhoto(selectedDoc.id, selectedDoc.filename);
                                      }}
                                    >
                                      <Download className="w-4 h-4 mr-2" />
                                      Download
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      onClick={() => setSelectedPhoto(null)}
                                    >
                                      <X className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </DialogTitle>
                              </DialogHeader>
                              <div className="flex justify-center">
                                <img 
                                  src={selectedPhoto} 
                                  alt={`${primaryVehicle.nickname || 'Vehicle'} photo`}
                                  className="max-w-full max-h-[70vh] object-contain rounded-lg"
                                />
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}
                      </div>
                    ) : (
                      <div className="mt-6">
                        <div className="mb-3">
                          <p className="text-sm font-medium text-gray-700 flex items-center">
                            <Camera className="w-4 h-4 mr-2 text-blue-600" />
                            Vehicle Photos (My Fleet)
                          </p>
                          <p className="text-xs text-gray-500">No photos found for {primaryVehicle.nickname || 'your vehicle'}</p>
                        </div>
                        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                          <Camera className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-500">Upload vehicle photos in <Link href="/my-fleet" className="text-blue-600 hover:underline">My Fleet</Link> section under Documents & Photos</p>
                        </div>
                      </div>
                    );
                  })()}
                </CardContent>
              </Card>
            )}

            {/* Recent Applications */}
            {appliedCompanies.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="w-5 h-5 mr-2 text-blue-600" />
                    Recent Applications
                  </CardTitle>
                  <CardDescription>Recently applied positions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {appliedCompanies.slice(0, 5).map((action: any, index: number) => {
                      const company = companies?.find((c: any) => c.id === action.companyId);
                      return (
                        <div key={index} className="flex items-center justify-between p-2 bg-blue-50 rounded-lg">
                          <div>
                            <p className="font-medium text-sm">{company?.name || 'Company'}</p>
                            <p className="text-xs text-gray-600">{company?.vehicleTypes?.join(', ')}</p>
                          </div>
                          <Badge className="bg-blue-100 text-blue-700">Applied</Badge>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="documents">
            <div className="max-w-6xl mx-auto">
              <div className="space-y-8">
                {/* Overview Section */}



                {/* Medical Certification Documents */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center">
                          <Shield className="w-5 h-5 mr-2 text-red-600" />
                          Medical Certification Documents
                        </CardTitle>
                        <CardDescription>
                          Healthcare and safety certifications for medical courier work
                        </CardDescription>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => {
                          // Get all uploaded medical certification documents
                          const medicalCertTypes = [
                            'hipaa_certification', 'osha_bloodborne', 'cpr_first_aid', 'hazmat_certification',
                            'iata_dot_certification', 'specimen_handling', 'biohazard_infectious', 'medical_waste_transport',
                            'chain_of_custody', 'defensive_driving', 'osha_general_industry', 'cold_chain_management',
                            'phlebotomy_tech', 'customer_service_training', 'tsa_certification', 'dangerous_goods_dg',
                            'dangerous_goods_dg7', 'custom_certification_1', 'custom_certification_2'
                          ];
                          const uploadedDocs = documents?.filter((doc: any) => medicalCertTypes.includes(doc.type)) || [];
                          
                          if (uploadedDocs.length === 0) {
                            alert('No medical certification documents to download');
                            return;
                          }
                          
                          // Download each document
                          uploadedDocs.forEach((doc: any, index: number) => {
                            setTimeout(() => {
                              window.open(`/api/documents/${doc.id}/download`, '_blank');
                            }, index * 500); // Stagger downloads by 500ms
                          });
                        }}
                        className="text-blue-600 border-blue-300 hover:bg-blue-50"
                        disabled={!documents?.some((doc: any) => [
                          'hipaa_certification', 'osha_bloodborne', 'cpr_first_aid', 'hazmat_certification',
                          'iata_dot_certification', 'specimen_handling', 'biohazard_infectious', 'medical_waste_transport',
                          'chain_of_custody', 'defensive_driving', 'osha_general_industry', 'cold_chain_management',
                          'phlebotomy_tech', 'customer_service_training', 'tsa_certification', 'dangerous_goods_dg',
                          'dangerous_goods_dg7', 'custom_certification_1', 'custom_certification_2'
                        ].includes(doc.type))}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download All
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {[
                        { type: 'hipaa_certification', name: 'HIPAA Certification', desc: 'Patient privacy compliance' },
                        { type: 'osha_bloodborne', name: 'OSHA Bloodborne Pathogens', desc: 'Safe specimen handling' },
                        { type: 'cpr_first_aid', name: 'CPR/First Aid', desc: 'Emergency response training' },
                        { type: 'hazmat_certification', name: 'HazMat Certification', desc: 'Hazardous materials transport' },
                        { type: 'iata_dot_certification', name: 'IATA/DOT Dangerous Goods', desc: 'Air/ground transport certification' },
                        { type: 'specimen_handling', name: 'Specimen Handling & Transport', desc: 'Collection and chain of custody' },
                        { type: 'biohazard_infectious', name: 'Biohazard & Infectious Substance', desc: 'High-risk biological materials' },
                        { type: 'medical_waste_transport', name: 'Medical Waste Transportation', desc: 'Regulated waste handling' },
                        { type: 'chain_of_custody', name: 'Chain of Custody', desc: 'Evidence handling procedures' },
                        { type: 'defensive_driving', name: 'Defensive Driving', desc: 'Safe driving certification' },
                        { type: 'osha_general_industry', name: 'OSHA General Industry', desc: 'Workplace safety standards' },
                        { type: 'cold_chain_management', name: 'Cold Chain Management', desc: 'Temperature-sensitive transport' },
                        { type: 'phlebotomy_tech', name: 'Phlebotomy Technician', desc: 'Blood collection certification' },
                        { type: 'customer_service_training', name: 'Customer Service Training', desc: 'Professional service skills' },
                        { type: 'tsa_certification', name: 'TSA Certification', desc: 'Transportation Security Administration' },
                        { type: 'dangerous_goods_dg', name: 'Dangerous Goods (DG) Certified', desc: 'General dangerous goods transport' },
                        { type: 'dangerous_goods_dg7', name: 'Dangerous Goods Class 7 (DG7)', desc: 'Radioactive materials transport' },
                        { type: 'custom_certification_1', name: 'Custom Certification 1', desc: 'User-defined certification' },
                        { type: 'custom_certification_2', name: 'Custom Certification 2', desc: 'User-defined certification' }
                      ].map((cert) => {
                        const userDoc = documents?.find((doc: any) => doc.type === cert.type);
                        return (
                          <div key={cert.type} className="border rounded-lg p-4 space-y-3 bg-white hover:shadow-md transition-shadow">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h3 className="font-semibold text-sm">{cert.name}</h3>
                                <p className="text-xs text-gray-500 mt-1">{cert.desc}</p>
                              </div>
                              <Badge variant="outline" className={userDoc ? "text-green-600 border-green-300 bg-green-50" : "text-gray-500 border-gray-300 bg-gray-50"}>
                                {userDoc ? (
                                  <>
                                    <CheckCircle className="w-3 h-3 mr-1" />
                                    Uploaded
                                  </>
                                ) : (
                                  <>
                                    <AlertTriangle className="w-3 h-3 mr-1" />
                                    Missing
                                  </>
                                )}
                              </Badge>
                            </div>
                            {userDoc && (
                              <div className="bg-gray-50 rounded p-3 space-y-2">
                                <div className="flex items-start gap-2">
                                  <FileText className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-sm font-medium text-gray-700 break-words">
                                      {userDoc.name || userDoc.filename}
                                    </p>
                                    {userDoc.uploadedAt && (
                                      <p className="text-xs text-gray-500 mt-1">
                                        Uploaded: {new Date(userDoc.uploadedAt).toLocaleDateString()}
                                      </p>
                                    )}
                                  </div>
                                </div>
                                <div className="flex justify-end space-x-2 pt-2 border-t border-gray-200">
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    onClick={() => window.open(`/api/documents/${userDoc.id}/view`, '_blank')} 
                                    className="text-xs px-2 py-1 h-7"
                                    title="View Document"
                                  >
                                    <Eye className="w-3 h-3 mr-1" />
                                    View
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    onClick={() => window.open(`/api/documents/${userDoc.id}/download`, '_blank')} 
                                    className="text-xs px-2 py-1 h-7"
                                    title="Download Document"
                                  >
                                    <Download className="w-3 h-3 mr-1" />
                                    Download
                                  </Button>
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>

                {/* Legal & Personal Documents */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center">
                          <FileText className="w-5 h-5 mr-2 text-purple-600" />
                          Legal & Personal Documents
                        </CardTitle>
                        <CardDescription>
                          Government identification and business documents
                        </CardDescription>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => {
                          // Get all uploaded legal/personal documents
                          const legalDocTypes = [
                            'government_id', 'business_license', 'tax_document', 
                            'contract', 'receipt', 'other'
                          ];
                          const uploadedDocs = documents?.filter((doc: any) => legalDocTypes.includes(doc.type)) || [];
                          
                          if (uploadedDocs.length === 0) {
                            alert('No legal or personal documents to download');
                            return;
                          }
                          
                          // Download each document
                          uploadedDocs.forEach((doc: any, index: number) => {
                            setTimeout(() => {
                              window.open(`/api/documents/${doc.id}/download`, '_blank');
                            }, index * 500); // Stagger downloads by 500ms
                          });
                        }}
                        className="text-purple-600 border-purple-300 hover:bg-purple-50"
                        disabled={!documents?.some((doc: any) => [
                          'government_id', 'business_license', 'tax_document', 
                          'contract', 'receipt', 'other'
                        ].includes(doc.type))}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Download All
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {[
                        { type: 'government_id', name: 'Government ID', desc: 'State ID or passport' },
                        { type: 'business_license', name: 'Business License', desc: 'Commercial operating permit' },
                        { type: 'tax_document', name: 'Tax Document', desc: 'W-9, 1099, or tax forms' },
                        { type: 'contract', name: 'Contract', desc: 'Employment or service agreements' },
                        { type: 'receipt', name: 'Receipt', desc: 'Payment and expense receipts' },
                        { type: 'other', name: 'Other Documents', desc: 'Additional supporting documents' }
                      ].map((docType) => {
                        const userDocs = documents?.filter((doc: any) => doc.type === docType.type) || [];
                        return (
                          <div key={docType.type} className="border rounded-lg p-4 space-y-3 bg-white hover:shadow-md transition-shadow">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h3 className="font-semibold text-sm">{docType.name}</h3>
                                <p className="text-xs text-gray-500 mt-1">{docType.desc}</p>
                              </div>
                              <Badge variant="outline" className={userDocs.length > 0 ? "text-green-600 border-green-300 bg-green-50" : "text-gray-500 border-gray-300 bg-gray-50"}>
                                {userDocs.length > 0 ? (
                                  <>
                                    <CheckCircle className="w-3 h-3 mr-1" />
                                    {userDocs.length} file{userDocs.length > 1 ? 's' : ''}
                                  </>
                                ) : (
                                  <>
                                    <AlertTriangle className="w-3 h-3 mr-1" />
                                    None
                                  </>
                                )}
                              </Badge>
                            </div>
                            {userDocs.length > 0 && (
                              <div className="space-y-2">
                                {userDocs.slice(0, 3).map((doc: any) => (
                                  <div key={doc.id} className="bg-gray-50 rounded p-3 space-y-2">
                                    <div className="flex items-start gap-2">
                                      <FileText className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
                                      <div className="flex-1 min-w-0">
                                        <p className="text-sm font-medium text-gray-700 break-words">
                                          {doc.name || doc.originalName || doc.fileName || doc.filename}
                                        </p>
                                        {doc.uploadedAt && (
                                          <p className="text-xs text-gray-500 mt-1">
                                            Uploaded: {new Date(doc.uploadedAt).toLocaleDateString()}
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                    <div className="flex justify-end space-x-2 pt-2 border-t border-gray-200">
                                      <Button 
                                        variant="outline" 
                                        size="sm" 
                                        onClick={() => window.open(`/api/documents/${doc.id}/view`, '_blank')} 
                                        className="text-xs px-2 py-1 h-7"
                                        title="View Document"
                                      >
                                        <Eye className="w-3 h-3 mr-1" />
                                        View
                                      </Button>
                                      <Button 
                                        variant="outline" 
                                        size="sm" 
                                        onClick={() => window.open(`/api/documents/${doc.id}/download`, '_blank')} 
                                        className="text-xs px-2 py-1 h-7"
                                        title="Download Document"
                                      >
                                        <Download className="w-3 h-3 mr-1" />
                                        Download
                                      </Button>
                                    </div>
                                  </div>
                                ))}
                                {userDocs.length > 3 && (
                                  <p className="text-xs text-gray-500 text-center">+ {userDocs.length - 3} more documents</p>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>



        {/* Company Modal */}
        <Dialog open={showCompanyModal} onOpenChange={setShowCompanyModal}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            {modalTitle} ({getFilteredCompanies(companies, companyActions, selectedFilter).length})
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {getFilteredCompanies(companies, companyActions, selectedFilter).map((company: any) => (
            <Card key={company.id} className="border border-slate-200 hover:border-slate-300 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg">
                      <Building2 className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{company.name}</h3>
                      <p className="text-sm text-gray-600">
                        {Array.isArray(company.serviceVertical) 
                          ? company.serviceVertical.join(', ') 
                          : company.serviceVertical || 'Service not specified'
                        }
                      </p>
                      <p className="text-xs text-gray-500">
                        {company.vehicleTypes?.join(', ') || 'Vehicle type not specified'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {getCompanyActionBadge(company.id, companyActions)}
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setShowCompanyModal(false);
                        setLocation(`/companies?filter=${selectedFilter}&company=${company.id}`);
                      }}
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {getFilteredCompanies(companies, companyActions, selectedFilter).length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Building2 className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p>No companies found for this category</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
      </div>
    </div>
  );
}

// Helper function to filter companies based on selected filter
function getFilteredCompanies(companies: any[], companyActions: any[], filter: string) {
  if (!companies || !companyActions) return [];

  const actionsMap: Record<number, string> = {};
  companyActions.forEach((action: any) => {
    actionsMap[action.companyId] = action.action;
  });

  switch (filter) {
    case 'active':
      return companies.filter(c => actionsMap[c.id] === 'active');
    case 'apply':
    case 'applied':
      return companies.filter(c => actionsMap[c.id] === 'apply' || actionsMap[c.id] === 'applied');
    case 'research':
      return companies.filter(c => actionsMap[c.id] === 'research');
    case 'waitinglist':
      return companies.filter(c => actionsMap[c.id] === 'waitinglist');
    case 'other':
      return companies.filter(c => actionsMap[c.id] === 'other');
    case 'newOpportunities':
      const now = new Date();
      const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      return companies.filter((company: any) => {
        const createdAt = new Date(company.createdAt || company.dateAdded);
        return createdAt > yesterday;
      });
    case 'all':
    default:
      return companies;
  }
}

// Helper function to get company action badge
function getCompanyActionBadge(companyId: number, companyActions: any[]) {
  if (!companyActions) return null;
  
  const action = companyActions.find(a => a.companyId === companyId)?.action;
  
  if (!action) return <Badge variant="outline">No Action</Badge>;
  
  const badgeStyles = {
    active: 'bg-green-100 text-green-700 border-green-300',
    research: 'bg-orange-100 text-orange-700 border-orange-300',
    waitinglist: 'bg-yellow-100 text-yellow-700 border-yellow-300',
    other: 'bg-gray-100 text-gray-700 border-gray-300',
    apply: 'bg-blue-100 text-blue-700 border-blue-300'
  };
  
  return (
    <Badge className={badgeStyles[action as keyof typeof badgeStyles] || 'bg-gray-100 text-gray-700'}>
      {action.charAt(0).toUpperCase() + action.slice(1)}
    </Badge>
  );
}