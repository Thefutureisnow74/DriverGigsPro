import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Calculator, 
  Receipt, 
  Car, 
  TrendingUp, 
  FileText, 
  DollarSign, 
  Shield, 
  Zap, 
  Clock, 
  Brain,
  MapPin,
  Fuel,
  Phone,
  Coffee,
  CreditCard,
  PieChart,
  BarChart3,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Target,
  Smartphone,
  Route,
  Eye,
  Calendar
} from "lucide-react";

export default function SmartTaxCenter() {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-green-50 to-emerald-50">
      {/* Header Section */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl mb-6 shadow-xl">
            <Calculator className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-slate-900 to-slate-600 bg-clip-text text-transparent mb-4">
            Smart Tax Center
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            AI-powered tax optimization for gig workers. Automatically track mileage, categorize expenses, and maximize your deductions with intelligent tax insights.
          </p>
          
          {/* Coming Soon Banner */}
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full text-white font-bold text-lg shadow-lg animate-pulse">
            <Clock className="h-5 w-5" />
            Coming Soon
          </div>
        </div>

        {/* Key Features Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          <Card className="hover:shadow-xl transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center pb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Route className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-xl font-bold text-gray-800">Smart Mileage Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Automatic GPS-based mileage tracking with business vs. personal trip classification. Never lose a deductible mile again.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center pb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Brain className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-xl font-bold text-gray-800">AI Expense Classification</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Intelligent categorization of expenses with IRS compliance suggestions and maximum deduction recommendations.
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader className="text-center pb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-xl font-bold text-gray-800">Tax Optimization</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 text-center">
                Real-time tax projections, quarterly estimate calculations, and year-end tax strategy recommendations.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Mileage Tracking Section */}
        <Card className="mb-12 border-0 bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader className="text-center pb-8">
            <CardTitle className="text-3xl font-bold text-gray-800 mb-4">Advanced Mileage Tracking</CardTitle>
            <p className="text-gray-600 text-lg">
              Maximize your mileage deductions with intelligent GPS tracking and automatic categorization
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Features List */}
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Smartphone className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 mb-2">Automatic Trip Detection</h4>
                    <p className="text-gray-600">GPS automatically detects when you start driving and logs trips in real-time.</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Target className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 mb-2">Purpose Classification</h4>
                    <p className="text-gray-600">AI learns your patterns to automatically classify trips as business, personal, or commuting.</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Receipt className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 mb-2">IRS-Compliant Reports</h4>
                    <p className="text-gray-600">Generate detailed mileage logs that meet IRS requirements for tax deductions.</p>
                  </div>
                </div>
              </div>

              {/* Mock Interface */}
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-6 border-2 border-dashed border-gray-300">
                <h4 className="font-bold text-gray-800 mb-4 text-center">Mileage Dashboard Preview</h4>
                <div className="space-y-4">
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold">This Month</span>
                      <Badge className="bg-green-500 text-white">2,347 miles</Badge>
                    </div>
                    <div className="text-sm text-gray-600">
                      <div>Business: 1,890 miles ($1,134.70 deduction)</div>
                      <div>Personal: 457 miles</div>
                    </div>
                  </div>
                  
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Recent Trip</span>
                      <span className="text-xs text-green-600">Business</span>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      Home → DoorDash Zone → Home<br/>
                      24.3 miles • $14.58 deduction
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Expense Categories Section */}
        <Card className="mb-12 border-0 bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-gray-800 mb-6 text-center">Intelligent Expense Categorization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl border border-blue-200">
                <div className="flex items-center gap-3 mb-4">
                  <Car className="h-6 w-6 text-blue-600" />
                  <h4 className="font-bold text-blue-800">Vehicle Expenses</h4>
                </div>
                <ul className="text-blue-700 text-sm space-y-1">
                  <li>• Gas & Fuel</li>
                  <li>• Maintenance & Repairs</li>
                  <li>• Insurance Premiums</li>
                  <li>• Vehicle Registration</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-xl border border-green-200">
                <div className="flex items-center gap-3 mb-4">
                  <Phone className="h-6 w-6 text-green-600" />
                  <h4 className="font-bold text-green-800">Communication</h4>
                </div>
                <ul className="text-green-700 text-sm space-y-1">
                  <li>• Phone & Data Plans</li>
                  <li>• GPS Apps</li>
                  <li>• Communication Tools</li>
                  <li>• Internet Service</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-indigo-50 p-6 rounded-xl border border-purple-200">
                <div className="flex items-center gap-3 mb-4">
                  <Coffee className="h-6 w-6 text-purple-600" />
                  <h4 className="font-bold text-purple-800">Meals & Travel</h4>
                </div>
                <ul className="text-purple-700 text-sm space-y-1">
                  <li>• Business Meals (50%)</li>
                  <li>• Travel Expenses</li>
                  <li>• Lodging</li>
                  <li>• Parking & Tolls</li>
                </ul>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-red-50 p-6 rounded-xl border border-orange-200">
                <div className="flex items-center gap-3 mb-4">
                  <FileText className="h-6 w-6 text-orange-600" />
                  <h4 className="font-bold text-orange-800">Business Services</h4>
                </div>
                <ul className="text-orange-700 text-sm space-y-1">
                  <li>• Banking Fees</li>
                  <li>• Professional Services</li>
                  <li>• Software Subscriptions</li>
                  <li>• Equipment Purchases</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tax Features Section */}
        <Card className="mb-12 border-0 bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader className="text-center pb-8">
            <CardTitle className="text-3xl font-bold text-gray-800 mb-4">Smart Tax Features</CardTitle>
            <p className="text-gray-600 text-lg">
              Automated tax calculations and optimization strategies for gig workers
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Quarterly Estimates */}
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Calendar className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Quarterly Estimates</h3>
                <p className="text-gray-600">
                  Automatic calculation of quarterly tax payments with safe harbor provisions and penalty avoidance strategies.
                </p>
              </div>

              {/* Deduction Maximizer */}
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <TrendingUp className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Deduction Maximizer</h3>
                <p className="text-gray-600">
                  AI identifies overlooked deductions and suggests strategies to minimize tax liability while staying IRS compliant.
                </p>
              </div>

              {/* Year-End Planning */}
              <div className="text-center">
                <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <PieChart className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">Year-End Planning</h3>
                <p className="text-gray-600">
                  Strategic recommendations for equipment purchases, retirement contributions, and other tax-saving moves.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Benefits Showcase */}
        <Card className="mb-12 border-0 bg-white/80 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="text-2xl font-bold text-gray-800 mb-6 text-center">Potential Tax Savings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-8 border border-green-200">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">$3,200</div>
                  <p className="text-green-700 font-semibold">Average Annual Mileage Deduction</p>
                  <p className="text-sm text-green-600 mt-1">Based on 5,000 business miles</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">$1,850</div>
                  <p className="text-green-700 font-semibold">Additional Expense Deductions</p>
                  <p className="text-sm text-green-600 mt-1">Phone, supplies, equipment</p>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">25%</div>
                  <p className="text-green-700 font-semibold">Potential Tax Rate Reduction</p>
                  <p className="text-sm text-green-600 mt-1">Through strategic deductions</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">Ready to Maximize Your Tax Savings?</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Smart Tax Center will help you keep more of what you earn with intelligent expense tracking and tax optimization.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              disabled
              className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg opacity-50 cursor-not-allowed"
            >
              <Calculator className="h-5 w-5 mr-2" />
              Coming Soon
            </Button>
            
            <Button 
              variant="outline" 
              size="lg"
              className="px-8 py-4 text-lg font-bold rounded-xl border-2 border-green-600 text-green-600 hover:bg-green-50"
              onClick={() => window.open('/expense-management', '_self')}
            >
              <Eye className="h-5 w-5 mr-2" />
              View Current Expenses
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}