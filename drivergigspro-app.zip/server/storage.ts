import {
  users,
  companies,
  applications,
  jobSearchNotes,
  courses,
  userCourseProgress,
  documents,
  expenses,
  contactLogs,
  userStats,
  taskBoards,
  taskLists,
  taskCards,
  vehicles,
  vehicleDocuments,
  vehicleMaintenanceItems,
  fuelCards,
  businessEntities,
  businessDocuments,
  businessFormationData,
  userActivity,
  adminLogs,
  userSavedFuelCards,
  fuelCardSpendHistory,
  newsletterSubscribers,
  jobBoardNotes,
  rideshareCompanies,
  userCompanyStatus,
  aiChatConversations,
  type User,
  type InsertUser,
  type UpsertUser,
  type BusinessEntity,
  type InsertBusinessEntity,
  type BusinessDocument,
  type InsertBusinessDocument,
  type BusinessFormationData,
  type InsertBusinessFormationData,
  type JobBoardNote,
  type InsertJobBoardNote,
  type Company,
  type InsertCompany,
  type Application,
  type InsertApplication,
  type ApplicationWithCompany,
  type Course,
  type UserStats,
  type TaskBoard,
  type InsertTaskBoard,
  type TaskList,
  type InsertTaskList,
  type TaskCard,
  type InsertTaskCard,
  type Vehicle,
  type InsertVehicle,
  type VehicleDocument,
  type InsertVehicleDocument,
  type VehicleMaintenanceItem,
  type InsertVehicleMaintenanceItem,
  type FuelCard,
  type InsertFuelCard,
  type UserSavedFuelCard,
  type InsertUserSavedFuelCard,
  type FuelCardSpendHistory,
  type InsertFuelCardSpendHistory,
  type UserActivity,
  type InsertUserActivity,
  type AdminLog,
  type InsertAdminLog,
  passwordResetTokens,
  type PasswordResetToken,
  type InsertPasswordResetToken,
  type CompanyAction,
  type InsertCompanyAction,
  companyActions,
  type NewsletterSubscriber,
  type InsertNewsletterSubscriber,
  type RideshareCompany,
  type InsertRideshareCompany,
  type UserCompanyStatus,
  type InsertUserCompanyStatus,
  type AiChatConversation,
  type InsertAiChatConversation,
  // VA System types
  userProfiles,
  addresses,
  emergencyContacts,
  userPreferences,
  gigApplications,
  vaActivity,
  vaAssignments,
  consentGrants,
  auditEvents,
  type UserProfile,
  type InsertUserProfile,
  type Address,
  type InsertAddress,
  type EmergencyContact,
  type InsertEmergencyContact,
  type UserPreferences,
  type InsertUserPreferences,
  type GigApplication,
  type InsertGigApplication,
  type VAActivity,
  type InsertVAActivity,
  type VAAssignment,
  type InsertVAAssignment,
  type ConsentGrant,
  type InsertConsentGrant,
  type AuditEvent,
  type InsertAuditEvent,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, lt, or, isNotNull, inArray, sql } from "drizzle-orm";

export interface IStorage {
  // Users
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: number): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // User Profile Management
  getUserProfile(userId: number): Promise<any | undefined>;
  updateUserProfile(userId: number, profileData: any): Promise<any>;
  updateUserPassword(userId: number, currentPassword: string, newPassword: string): Promise<boolean>;

  // Companies
  getAllCompanies(): Promise<Company[]>;
  getCompanies(): Promise<Company[]>;
  getCompany(id: number): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;
  checkCompanyExists(name: string, website?: string): Promise<Company | undefined>;
  createCompanyWithDuplicateCheck(company: InsertCompany): Promise<{ company: Company; isNew: boolean }>;
  updateCompany(id: number, company: Partial<InsertCompany>): Promise<Company | undefined>;
  deleteCompany(id: number): Promise<boolean>;
  searchCompanies(query: string): Promise<Company[]>;

  // Applications
  getUserApplications(userId: number): Promise<ApplicationWithCompany[]>;
  getApplicationsWithCompanies(userId: number): Promise<ApplicationWithCompany[]>;
  getApplication(id: number): Promise<Application | undefined>;
  getApplicationByCompanyId(userId: number, companyId: number): Promise<Application | undefined>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplication(id: number, application: Partial<InsertApplication>): Promise<Application | undefined>;
  deleteApplication(id: number): Promise<boolean>;

  // Job Search Notes
  createJobSearchNote(noteData: any): Promise<any>;
  getJobSearchNotes(userId: number, companyId: number): Promise<any[]>;
  updateJobSearchNote(noteId: number, updates: any): Promise<any>;
  removeAllRemindersForCompany(userId: number, companyId: number): Promise<any>;
  
  // Job Board Notes
  getJobBoardNotes(userId: number): Promise<JobBoardNote[]>;
  updateJobBoardNote(userId: number, jobBoardName: string, notes: string): Promise<JobBoardNote>;



  // Courses
  getAllCourses(): Promise<Course[]>;
  getUserCourseProgress(userId: number): Promise<any[]>;

  // User Stats
  getUserStats(userId: number): Promise<UserStats | undefined>;
  updateUserStats(userId: number, stats: Partial<UserStats>): Promise<UserStats>;

  // Business Entities
  getUserBusinessEntities(userId: number): Promise<BusinessEntity[]>;
  getBusinessEntity(id: number): Promise<BusinessEntity | undefined>;
  createBusinessEntity(entity: InsertBusinessEntity): Promise<BusinessEntity>;
  updateBusinessEntity(id: number, entity: Partial<InsertBusinessEntity>): Promise<BusinessEntity | undefined>;
  deleteBusinessEntity(id: number): Promise<boolean>;

  // Business Documents
  getBusinessDocuments(businessEntityId: number): Promise<BusinessDocument[]>;
  getUserBusinessDocuments(userId: number): Promise<BusinessDocument[]>;
  getBusinessDocument(id: number): Promise<BusinessDocument | undefined>;
  createBusinessDocument(document: InsertBusinessDocument): Promise<BusinessDocument>;
  updateBusinessDocument(id: number, document: Partial<InsertBusinessDocument>): Promise<BusinessDocument | undefined>;
  deleteBusinessDocument(id: number): Promise<boolean>;

  // Business Formation Data
  getBusinessFormationData(userId: number, businessId: string): Promise<BusinessFormationData | undefined>;
  saveBusinessFormationData(data: InsertBusinessFormationData): Promise<BusinessFormationData>;

  // Vehicles
  getUserVehicles(userId: string): Promise<Vehicle[]>;
  
  // Vehicle Documents
  getVehicleDocuments(vehicleId: number): Promise<VehicleDocument[]>;
  getVehicleDocument(id: number): Promise<VehicleDocument | undefined>;
  createVehicleDocument(document: InsertVehicleDocument): Promise<VehicleDocument>;
  deleteVehicleDocument(id: number): Promise<boolean>;
  
  // Vehicle Maintenance Items
  getVehicleMaintenanceItems(vehicleId: number): Promise<VehicleMaintenanceItem[]>;
  getVehicleMaintenanceItem(id: number): Promise<VehicleMaintenanceItem | undefined>;
  createVehicleMaintenanceItem(item: InsertVehicleMaintenanceItem): Promise<VehicleMaintenanceItem>;
  updateVehicleMaintenanceItem(id: number, item: Partial<InsertVehicleMaintenanceItem>): Promise<VehicleMaintenanceItem | undefined>;
  deleteVehicleMaintenanceItem(id: number): Promise<boolean>;
  
  // General Documents
  getUserDocuments(userId: string): Promise<any[]>;
  createDocument(document: any): Promise<any>;
  deleteDocument(id: number, userId: string): Promise<boolean>;
  getDocumentById(documentId: number, userId: string): Promise<any | undefined>;
  getVehicle(id: number): Promise<Vehicle | undefined>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicle(id: number, vehicle: Partial<InsertVehicle>): Promise<Vehicle | undefined>;
  deleteVehicle(id: number): Promise<boolean>;

  // Activity Tracking
  logUserActivity(activity: InsertUserActivity): Promise<UserActivity>;
  getUserActivity(userId: string, limit?: number): Promise<UserActivity[]>;

  // Password Reset
  createPasswordResetToken(userId: string, email: string, token: string, expiresAt: Date): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markPasswordResetTokenUsed(tokenId: number): Promise<void>;
  cleanupExpiredTokens(): Promise<void>;

  // Task Boards
  getUserTaskBoards(userId: string): Promise<TaskBoard[]>;
  getTaskBoard(id: number): Promise<TaskBoard | undefined>;
  createTaskBoard(board: InsertTaskBoard): Promise<TaskBoard>;
  updateTaskBoard(id: number, board: Partial<InsertTaskBoard>): Promise<TaskBoard | undefined>;
  deleteTaskBoard(id: number): Promise<boolean>;

  // Task Lists
  getBoardLists(boardId: number): Promise<TaskList[]>;
  getTaskList(id: number): Promise<TaskList | undefined>;
  createTaskList(list: InsertTaskList): Promise<TaskList>;
  updateTaskList(id: number, list: Partial<InsertTaskList>): Promise<TaskList | undefined>;
  deleteTaskList(id: number): Promise<boolean>;

  // Task Cards
  getUserTaskCards(userId: string): Promise<TaskCard[]>;
  getListCards(listId: number): Promise<TaskCard[]>;
  getTaskCard(id: number): Promise<TaskCard | undefined>;
  createTaskCard(card: InsertTaskCard): Promise<TaskCard>;
  updateTaskCard(id: number, card: Partial<InsertTaskCard>): Promise<TaskCard | undefined>;
  deleteTaskCard(id: number): Promise<boolean>;
  moveTaskCard(cardId: number, targetListId: number, position: number): Promise<TaskCard | undefined>;
  addTaskCardComment(cardId: number, commentData: { text: string; userId: string; userName: string; createdAt: string }): Promise<TaskCard | undefined>;
  
  // Calendar Integration
  getTaskCalendarEvents(userId: string): Promise<Array<{
    id: number;
    title: string;
    startDate: Date | null;
    dueDate: Date | null;
    reminderDays: number | null;
    type: 'task';
    boardTitle: string;
    listTitle: string;
  }>>;
  
  // User Saved Fuel Cards
  getUserSavedFuelCards(userId: string): Promise<UserSavedFuelCard[]>;
  getUserSavedFuelCard(cardId: number): Promise<UserSavedFuelCard | undefined>;
  createUserSavedFuelCard(card: InsertUserSavedFuelCard): Promise<UserSavedFuelCard>;
  updateUserSavedFuelCard(cardId: number, updates: Partial<UserSavedFuelCard>): Promise<UserSavedFuelCard | undefined>;
  deleteUserSavedFuelCard(cardId: number): Promise<boolean>;
  
  // Fuel Card Spend History
  getFuelCardSpendHistory(cardId: number, userId: string): Promise<FuelCardSpendHistory[]>;
  createFuelCardSpendHistory(spend: InsertFuelCardSpendHistory): Promise<FuelCardSpendHistory>;

  // Newsletter Subscribers
  createNewsletterSubscriber(subscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber>;
  getNewsletterSubscribers(): Promise<NewsletterSubscriber[]>;

  // GigBot Rideshare Companies
  getAllRideshareCompanies(): Promise<RideshareCompany[]>;
  getRideshareCompany(id: number): Promise<RideshareCompany | undefined>;
  createRideshareCompany(company: InsertRideshareCompany): Promise<RideshareCompany>;
  updateRideshareCompany(id: number, company: Partial<InsertRideshareCompany>): Promise<RideshareCompany | undefined>;
  
  // User Company Status
  getUserCompanyStatus(userId: number, companyId: number): Promise<UserCompanyStatus | undefined>;
  createUserCompanyStatus(status: InsertUserCompanyStatus): Promise<UserCompanyStatus>;
  updateUserCompanyStatus(userId: number, companyId: number, updates: Partial<InsertUserCompanyStatus>): Promise<UserCompanyStatus | undefined>;
  getActiveRideshareCompaniesForUser(userId: number): Promise<(RideshareCompany & { status: UserCompanyStatus })[]>;
  getNonActiveRideshareCompaniesForUser(userId: number): Promise<RideshareCompany[]>;
  
  // AI Chat Conversations
  saveAiChatMessage(userId: string, sessionId: string, message: { role: string; content: string; messageId?: string; toolCalls?: any }): Promise<any>;
  getAiChatHistory(userId: string, sessionId: string, limit?: number): Promise<any[]>;


  // === VA SYSTEM INTERFACE ===
  // Profile Stats
  getProfileStats(userId: number): Promise<{ completenessScore: number; totalApplications: number; activeApplications: number; vaActivitiesCount: number; lastActivityDate?: string }>;

  // Address Management
  getUserAddresses(userId: number): Promise<Address[]>;
  createAddress(address: InsertAddress): Promise<Address>;
  updateAddress(id: number, address: Partial<InsertAddress>): Promise<Address | undefined>;
  deleteAddress(id: number): Promise<boolean>;

  // Emergency Contacts
  getEmergencyContacts(userId: number): Promise<EmergencyContact[]>;
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  updateEmergencyContact(id: number, contact: Partial<InsertEmergencyContact>): Promise<EmergencyContact | undefined>;
  deleteEmergencyContact(id: number): Promise<boolean>;

  // User Preferences
  getUserPreferences(userId: number): Promise<UserPreferences | undefined>;
  updateUserPreferences(userId: number, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences>;

  // Vehicle Management (enhanced)
  getVehicles(userId: number): Promise<Vehicle[]>;
  
  // Gig Applications
  getGigApplications(userId: number, filters?: { status?: string; limit?: number; offset?: number }): Promise<GigApplication[]>;
  createGigApplication(application: InsertGigApplication): Promise<GigApplication>;
  updateGigApplication(id: number, application: Partial<InsertGigApplication>): Promise<GigApplication | undefined>;
  deleteGigApplication(id: number): Promise<boolean>;

  // VA Activities
  getVAActivities(userId: number, filters?: { dateRange?: string; activityType?: string; channel?: string; company?: string; limit?: number; offset?: number }): Promise<VAActivity[]>;
  createVAActivity(activity: InsertVAActivity): Promise<VAActivity>;
  updateVAActivity(id: number, activity: Partial<InsertVAActivity>): Promise<VAActivity | undefined>;
  deleteVAActivity(id: number): Promise<boolean>;
  getVAActivityStats(userId: number): Promise<{ totalActivities: number; thisMonth: number; avgDurationMin: number; completedTasks: number; pendingTasks: number }>;

  // VA Assignments
  getVAAssignments(userId: number): Promise<VAAssignment[]>;
  createVAAssignment(assignment: InsertVAAssignment): Promise<VAAssignment>;
  updateVAAssignment(id: number, assignment: Partial<InsertVAAssignment>): Promise<VAAssignment | undefined>;
  deleteVAAssignment(id: number): Promise<boolean>;

  // Consent Grants for RBAC
  getConsentGrants(userId: number): Promise<ConsentGrant[]>;
  createConsentGrant(grant: InsertConsentGrant): Promise<ConsentGrant>;
  revokeConsentGrant(id: number): Promise<boolean>;

  // Audit Events
  getAuditEvents(userId: number, options?: { limit?: number; offset?: number }): Promise<AuditEvent[]>;
  createAuditEvent(event: InsertAuditEvent): Promise<AuditEvent>;

  // Dismissed Recommendations
  getDismissedRecommendations(userId: number): Promise<{ companyId: number; companyName: string; dismissedAt: Date; reason?: string }[]>;
  dismissRecommendation(userId: number, companyId: number, companyName: string, reason?: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // Job Board Notes operations
  async getJobBoardNotes(userId: number): Promise<JobBoardNote[]> {
    const notes = await db.select().from(jobBoardNotes).where(eq(jobBoardNotes.userId, userId));
    return notes;
  }

  async updateJobBoardNote(userId: number, jobBoardName: string, notes: string): Promise<JobBoardNote> {
    try {
      const [existingNote] = await db.select().from(jobBoardNotes)
        .where(and(eq(jobBoardNotes.userId, userId), eq(jobBoardNotes.jobBoardName, jobBoardName)));

      if (existingNote) {
        const [updatedNote] = await db.update(jobBoardNotes)
          .set({ notes, updatedAt: new Date() })
          .where(and(eq(jobBoardNotes.userId, userId), eq(jobBoardNotes.jobBoardName, jobBoardName)))
          .returning();
        return updatedNote;
      } else {
        const [newNote] = await db.insert(jobBoardNotes)
          .values({ userId, jobBoardName, notes })
          .returning();
        return newNote;
      }
    } catch (error) {
      console.error('Error updating job board note:', error);
      throw error;
    }
  }

  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(user)
      .where(eq(users.id, id))
      .returning();
    return updatedUser || undefined;
  }

  // User Profile Management
  async getUserProfile(userId: number): Promise<any | undefined> {
    // Get the user data which includes extended profile info
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) return undefined;
    
    // Return profile data (excluding sensitive fields)
    return {
      username: user.username,
      email: user.email || '',
      phone: user.phone || '',
      address: user.address || '',
      city: user.city || '',
      state: user.state || '',
      zipCode: user.zipCode || '',
      dateOfBirth: user.dateOfBirth ? 
        (user.dateOfBirth instanceof Date ? user.dateOfBirth.toISOString().split('T')[0] : 
         typeof user.dateOfBirth === 'string' ? user.dateOfBirth.split('T')[0] : '') : '',
      bio: user.bio || '',
      profileImageUrl: user.profileImageUrl || '',
      fullName: user.fullName || '',
      firstName: user.firstName || '',
      lastName: user.lastName || '',
      dotNumber: user.dotNumber || '',
      mcNumber: user.mcNumber || '',
      gigGoals: user.gigGoals || '',
      createdAt: user.createdAt
    };
  }

  async updateUserProfile(userId: string, profileData: any): Promise<any> {
    // Update the user record with the new profile data
    const updateData: any = {
      updatedAt: new Date()
    };

    if (profileData.firstName) updateData.firstName = profileData.firstName;
    if (profileData.lastName) updateData.lastName = profileData.lastName;
    if (profileData.email) updateData.email = profileData.email;
    if (profileData.username) updateData.username = profileData.username;
    if (profileData.phone !== undefined) updateData.phone = profileData.phone;
    if (profileData.address !== undefined) updateData.address = profileData.address;
    if (profileData.city !== undefined) updateData.city = profileData.city;
    if (profileData.state !== undefined) updateData.state = profileData.state;
    if (profileData.zipCode !== undefined) updateData.zipCode = profileData.zipCode;
    if (profileData.dateOfBirth !== undefined) updateData.dateOfBirth = profileData.dateOfBirth ? new Date(profileData.dateOfBirth) : null;
    if (profileData.bio !== undefined) updateData.bio = profileData.bio;
    if (profileData.profileImageUrl !== undefined) updateData.profileImageUrl = profileData.profileImageUrl;
    if (profileData.dotNumber !== undefined) updateData.dotNumber = profileData.dotNumber;
    if (profileData.mcNumber !== undefined) updateData.mcNumber = profileData.mcNumber;
    if (profileData.gigGoals !== undefined) updateData.gigGoals = profileData.gigGoals;
    
    // Update full name from first/last name
    if (profileData.firstName || profileData.lastName) {
      const firstName = profileData.firstName || '';
      const lastName = profileData.lastName || '';
      updateData.fullName = `${firstName} ${lastName}`.trim();
    }

    const [updatedUser] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning();

    return updatedUser;
  }

  async updateUserPassword(userId: string, currentPassword: string, newPassword: string): Promise<boolean> {
    // Get the current user
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    if (!user) return false;

    // For OAuth users, we don't verify the current password since they don't have one
    // In a real app, you'd use bcrypt to compare passwords
    
    // Update the password (in a real app, hash it with bcrypt)
    await db
      .update(users)
      .set({ 
        password: newPassword, // In production, hash this
        updatedAt: new Date() 
      })
      .where(eq(users.id, userId));

    return true;
  }

  async getAllCompanies(): Promise<Company[]> {
    return await db.select().from(companies).where(eq(companies.isActive, true)).orderBy(companies.name);
  }

  async getCompanies(): Promise<Company[]> {
    return await db.select().from(companies).where(eq(companies.isActive, true)).orderBy(companies.name);
  }

  async getCompany(id: number): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company || undefined;
  }

  async createCompany(company: InsertCompany): Promise<Company> {
    const [newCompany] = await db.insert(companies).values(company).returning();
    return newCompany;
  }

  async checkCompanyExists(name: string, website?: string): Promise<Company | undefined> {
    // Check by name first
    let query = db.select().from(companies).where(eq(companies.name, name));
    const [existingByName] = await query;
    
    if (existingByName) {
      return existingByName;
    }
    
    // If website provided, also check by website
    if (website) {
      const [existingByWebsite] = await db.select().from(companies).where(eq(companies.website, website));
      if (existingByWebsite) {
        return existingByWebsite;
      }
    }
    
    return undefined;
  }

  async createCompanyWithDuplicateCheck(company: InsertCompany): Promise<{ company: Company; isNew: boolean }> {
    // Check for duplicates
    const existing = await this.checkCompanyExists(company.name, company.website);
    
    if (existing) {
      console.log(`⚠️ Company "${company.name}" already exists (ID: ${existing.id}). Skipping creation.`);
      return { company: existing, isNew: false };
    }
    
    // Create new company if no duplicates found
    const newCompany = await this.createCompany(company);
    console.log(`✅ Created new company: ${company.name} (ID: ${newCompany.id})`);
    return { company: newCompany, isNew: true };
  }

  async updateCompany(id: number, company: Partial<InsertCompany>): Promise<Company | undefined> {
    const [updatedCompany] = await db
      .update(companies)
      .set(company)
      .where(eq(companies.id, id))
      .returning();
    return updatedCompany || undefined;
  }

  async deleteCompany(id: number): Promise<boolean> {
    const result = await db.update(companies).set({ isActive: false }).where(eq(companies.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async bulkDeleteCompanies(companyIds: number[]): Promise<number> {
    if (companyIds.length === 0) return 0;
    
    console.log(`🗑️ Storage: Deleting ${companyIds.length} companies with IDs:`, companyIds.slice(0, 10));
    
    const result = await db.update(companies).set({ isActive: false }).where(inArray(companies.id, companyIds));
    const deletedCount = result.rowCount || 0;
    
    console.log(`✅ Storage: Successfully deleted ${deletedCount} companies`);
    return deletedCount;
  }

  async searchCompanies(query: string): Promise<Company[]> {
    const allCompanies = await this.getAllCompanies();
    return allCompanies.filter(company =>
      company.name.toLowerCase().includes(query.toLowerCase()) ||
      company.serviceVertical.toLowerCase().includes(query.toLowerCase())
    );
  }













  // Job Search Notes
  async createJobSearchNote(noteData: any): Promise<any> {
    // First, check if an application exists for this company and user
    let applicationId = null;
    
    const existingApplication = await db
      .select()
      .from(applications)
      .where(
        and(
          eq(applications.userId, parseInt(noteData.userId)),
          eq(applications.companyId, noteData.companyId)
        )
      );

    if (existingApplication.length > 0) {
      applicationId = existingApplication[0].id;
    } else {
      // Create a new application record
      const [newApplication] = await db
        .insert(applications)
        .values({
          userId: parseInt(noteData.userId),
          companyId: noteData.companyId,
          position: "Driver", // Default position
          status: "Interested",
        })
        .returning();
      applicationId = newApplication.id;
    }

    // Create the job search note
    const [note] = await db
      .insert(jobSearchNotes)
      .values({
        ...noteData,
        applicationId,
      })
      .returning();

    return note;
  }

  async getJobSearchNotes(userId: string, companyId: number): Promise<any[]> {
    const notes = await db
      .select()
      .from(jobSearchNotes)
      .where(
        and(
          eq(jobSearchNotes.userId, userId),
          eq(jobSearchNotes.companyId, companyId)
        )
      )
      .orderBy(desc(jobSearchNotes.createdAt))
      .limit(1); // Only get the most recent note for faster queries
    
    return notes;
  }

  async updateJobSearchNote(noteId: number, updates: any): Promise<any> {
    const [updatedNote] = await db
      .update(jobSearchNotes)
      .set(updates)
      .where(eq(jobSearchNotes.id, noteId))
      .returning();
    
    return updatedNote;
  }

  async removeAllRemindersForCompany(userId: string, companyId: number): Promise<any> {
    console.log(`Removing ALL reminders for user ${userId}, company ${companyId}`);
    
    // Update ALL job search notes for this company to remove reminder fields
    const result = await db
      .update(jobSearchNotes)
      .set({
        reminderDate: null,
        reminderTime: null,
        reminderText: null
      })
      .where(
        and(
          eq(jobSearchNotes.userId, userId),
          eq(jobSearchNotes.companyId, companyId),
          isNotNull(jobSearchNotes.reminderDate)
        )
      )
      .returning();
    
    console.log(`Updated ${result.length} reminder records for company ${companyId}`);
    return { updatedCount: result.length, updatedRecords: result };
  }

  // Reminders operations
  async getActiveReminders(userId: string): Promise<any[]> {
    // Get company reminders
    const companyReminders = await db
      .select({
        id: jobSearchNotes.id,
        companyId: jobSearchNotes.companyId,
        companyName: companies.name,
        reminderDate: jobSearchNotes.reminderDate,
        reminderText: jobSearchNotes.reminderText,
        contactName: jobSearchNotes.contactName,
        phoneNumber: jobSearchNotes.phoneNumber,
        emailAddress: jobSearchNotes.emailAddress,
        notes: jobSearchNotes.notes,
        createdAt: jobSearchNotes.createdAt,
        type: sql<string>`'company'`,
        cardId: sql<number | null>`NULL`,
        cardTitle: sql<string | null>`NULL`,
        dueDate: sql<Date | null>`NULL`,
      })
      .from(jobSearchNotes)
      .innerJoin(companies, eq(jobSearchNotes.companyId, companies.id))
      .where(
        and(
          eq(jobSearchNotes.userId, userId),
          isNotNull(jobSearchNotes.reminderDate)
        )
      );

    // Get task card reminders
    const taskReminders = await db
      .select({
        id: taskCards.id,
        companyId: sql<number | null>`NULL`,
        companyName: sql<string | null>`NULL`,
        reminderDate: sql<Date>`${taskCards.dueDate} - (${taskCards.reminderDays} || ' days')::interval`,
        reminderText: taskCards.title,
        contactName: sql<string | null>`NULL`,
        phoneNumber: sql<string | null>`NULL`,
        emailAddress: sql<string | null>`NULL`,
        notes: taskCards.description,
        createdAt: taskCards.createdAt,
        type: sql<string>`'task'`,
        cardId: taskCards.id,
        cardTitle: taskCards.title,
        dueDate: taskCards.dueDate,
      })
      .from(taskCards)
      .innerJoin(taskLists, eq(taskCards.listId, taskLists.id))
      .innerJoin(taskBoards, eq(taskLists.boardId, taskBoards.id))
      .where(
        and(
          eq(taskBoards.userId, userId),
          isNotNull(taskCards.dueDate),
          isNotNull(taskCards.reminderDays),
          sql`${taskCards.dueDate} - (${taskCards.reminderDays} || ' days')::interval >= CURRENT_DATE - INTERVAL '30 days'`
        )
      );

    // Combine and sort by reminder date
    const allReminders = [...companyReminders, ...taskReminders];
    return allReminders.sort((a, b) => {
      const dateA = a.reminderDate ? new Date(a.reminderDate).getTime() : 0;
      const dateB = b.reminderDate ? new Date(b.reminderDate).getTime() : 0;
      return dateA - dateB;
    });
  }

  async getAllCourses(): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.isActive, true)).orderBy(courses.title);
  }

  async getUserCourseProgress(userId: number): Promise<any[]> {
    const progress = await db
      .select({
        courseId: userCourseProgress.courseId,
        progress: userCourseProgress.progress,
        completed: userCourseProgress.completed,
        title: courses.title,
        vertical: courses.vertical,
      })
      .from(userCourseProgress)
      .leftJoin(courses, eq(userCourseProgress.courseId, courses.id))
      .where(eq(userCourseProgress.userId, userId));
    
    return progress;
  }

  async getUserStats(userId: number): Promise<UserStats | undefined> {
    try {
      // Calculate real active companies from company_actions table
      const [activeCompaniesResult] = await db
        .select({ count: sql<number>`count(*)`.as('count') })
        .from(companyActions)
        .where(and(eq(companyActions.userId, userId.toString()), eq(companyActions.action, 'active')));
      
      // Calculate total applications
      const [totalApplicationsResult] = await db
        .select({ count: sql<number>`count(*)`.as('count') })
        .from(applications)
        .where(eq(applications.userId, userId));

      // Calculate completion rate based on hired vs total applications
      const [hiredJobsResult] = await db
        .select({ count: sql<number>`count(*)`.as('count') })
        .from(applications)
        .where(and(eq(applications.userId, userId), eq(applications.status, 'hired')));

      const activeCompanies = Number(activeCompaniesResult?.count || 0);
      const totalApplications = Number(totalApplicationsResult?.count || 0);
      const hiredJobs = Number(hiredJobsResult?.count || 0);
      const completionRate = totalApplications > 0 ? (hiredJobs / totalApplications) * 100 : 0;

      // Try to get existing stats record, or create default
      let [existingStats] = await db.select().from(userStats).where(eq(userStats.userId, userId));
      
      if (!existingStats) {
        // Create default stats record for new users
        [existingStats] = await db.insert(userStats).values({
          userId: userId,
          activeJobs: activeCompanies, // Now represents active companies
          weeklyEarnings: 0,
          totalApplications: totalApplications,
          completionRate: completionRate,
          updatedAt: new Date()
        }).returning();
      } else {
        // Update existing stats with real calculated values
        [existingStats] = await db.update(userStats)
          .set({
            activeJobs: activeCompanies, // Now represents active companies
            totalApplications: totalApplications,
            completionRate: completionRate,
            updatedAt: new Date()
          })
          .where(eq(userStats.userId, userId))
          .returning();
      }

      return existingStats;
    } catch (error) {
      console.error("Error calculating user stats:", error);
      return undefined;
    }
  }

  async updateUserStats(userId: number, stats: Partial<UserStats>): Promise<UserStats> {
    const existing = await this.getUserStats(userId);
    if (existing) {
      const [updated] = await db
        .update(userStats)
        .set({ ...stats, updatedAt: new Date() })
        .where(eq(userStats.userId, userId))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(userStats)
        .values({ userId, ...stats })
        .returning();
      return created;
    }
  }

  // Business Entities
  async getUserBusinessEntities(userId: number): Promise<BusinessEntity[]> {
    // Select only core fields that definitely exist to avoid schema mismatches
    return await db.select({
      id: businessEntities.id,
      userId: businessEntities.userId,
      companyName: businessEntities.companyName,
      businessType: businessEntities.businessType,
      status: businessEntities.status,
      ein: businessEntities.ein,
      stateOfOrganization: businessEntities.stateOfOrganization,
      formationDate: businessEntities.formationDate,
      companyAddress: businessEntities.companyAddress,
      companyPhone: businessEntities.companyPhone,
      email: businessEntities.email,
      website: businessEntities.website,
      createdAt: businessEntities.createdAt,
      updatedAt: businessEntities.updatedAt
    }).from(businessEntities).where(eq(businessEntities.userId, userId));
  }

  async getBusinessEntity(id: number): Promise<BusinessEntity | undefined> {
    try {
      // Use raw SQL to avoid schema mismatch issues
      const result = await db.execute(sql`SELECT * FROM business_entities WHERE id = ${id} LIMIT 1`);
      const entity = result.rows[0] as any;
      return entity || undefined;
    } catch (error) {
      console.error("Error fetching business entity:", error);
      return undefined;
    }
  }

  async createBusinessEntity(entity: InsertBusinessEntity): Promise<BusinessEntity> {
    const [newEntity] = await db
      .insert(businessEntities)
      .values(entity)
      .returning();
    return newEntity;
  }

  async updateBusinessEntity(id: number, entity: Partial<InsertBusinessEntity>): Promise<BusinessEntity | undefined> {
    try {
      // Simple direct update using Drizzle ORM
      const [updatedEntity] = await db
        .update(businessEntities)
        .set(entity)
        .where(eq(businessEntities.id, id))
        .returning();
      
      return updatedEntity;
    } catch (error) {
      console.error("Error updating business entity:", error);
      return undefined;
    }
  }

  async updateBusinessEntityField(id: number, field: string, value: any): Promise<BusinessEntity | undefined> {
    try {
      // Simple field update
      const updateData = { [field]: value };
      return await this.updateBusinessEntity(id, updateData);
    } catch (error) {
      console.error("Error updating business entity field:", error);
      return undefined;
    }
  }

  async deleteBusinessEntity(id: number): Promise<boolean> {
    try {
      await db.delete(businessEntities).where(eq(businessEntities.id, id));
      return true;
    } catch (error) {
      return false;
    }
  }


  // === VA SYSTEM STORAGE IMPLEMENTATION ===

  // Profile Stats
  async getProfileStats(userId: number): Promise<{ completenessScore: number; totalApplications: number; activeApplications: number; vaActivitiesCount: number; lastActivityDate?: string }> {
    try {
      // Get user profile completeness
      const [user] = await db.select().from(users).where(eq(users.id, userId));
      let completenessScore = 0;
      if (user) {
        const fields = [user.firstName, user.lastName, user.email, user.phone];
        completenessScore = Math.round((fields.filter(f => f).length / fields.length) * 100);
      }

      // Get application counts - using regular applications table for now
      const apps = await db.select().from(applications).where(eq(applications.userId, userId));
      const totalApplications = apps.length;
      const activeApplications = apps.filter(a => ['applied', 'interview', 'offer'].includes(a.status || '')).length;

      // Get VA activities count - stub for now since table may not exist yet
      const vaActivitiesCount = 0;

      return {
        completenessScore,
        totalApplications,
        activeApplications,
        vaActivitiesCount
      };
    } catch (error) {
      console.error('Error getting profile stats:', error);
      return {
        completenessScore: 0,
        totalApplications: 0,
        activeApplications: 0,
        vaActivitiesCount: 0
      };
    }
  }

  // Address Management - stubbed for now
  async getUserAddresses(userId: number): Promise<Address[]> {
    return [];
  }

  async createAddress(address: InsertAddress): Promise<Address> {
    throw new Error('Address management not yet implemented');
  }

  async updateAddress(id: number, address: Partial<InsertAddress>): Promise<Address | undefined> {
    return undefined;
  }

  async deleteAddress(id: number): Promise<boolean> {
    return false;
  }

  // Emergency Contacts - stubbed
  async getEmergencyContacts(userId: number): Promise<EmergencyContact[]> {
    return [];
  }

  async createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact> {
    throw new Error('Emergency contacts not yet implemented');
  }

  async updateEmergencyContact(id: number, contact: Partial<InsertEmergencyContact>): Promise<EmergencyContact | undefined> {
    return undefined;
  }

  async deleteEmergencyContact(id: number): Promise<boolean> {
    return false;
  }

  // User Preferences - stubbed
  async getUserPreferences(userId: number): Promise<UserPreferences | undefined> {
    return undefined;
  }

  async updateUserPreferences(userId: number, preferences: Partial<InsertUserPreferences>): Promise<UserPreferences> {
    throw new Error('User preferences not yet implemented');
  }

  // Enhanced Vehicle Management
  async getVehicles(userId: number): Promise<Vehicle[]> {
    try {
      const userVehicles = await db.select().from(vehicles).where(eq(vehicles.userId, userId.toString()));
      return userVehicles;
    } catch (error) {
      console.error('Error getting vehicles:', error);
      return [];
    }
  }

  async getUserVehicles(userId: string): Promise<Vehicle[]> {
    try {
      const userVehicles = await db.select().from(vehicles).where(eq(vehicles.userId, userId));
      return userVehicles;
    } catch (error) {
      console.error('Error getting user vehicles:', error);
      return [];
    }
  }

  // Gig Applications - stubbed for now
  async getGigApplications(userId: number, filters: { status?: string; limit?: number; offset?: number } = {}): Promise<GigApplication[]> {
    return [];
  }

  async createGigApplication(application: InsertGigApplication): Promise<GigApplication> {
    throw new Error('Gig applications not yet implemented');
  }

  async updateGigApplication(id: number, application: Partial<InsertGigApplication>): Promise<GigApplication | undefined> {
    return undefined;
  }

  async deleteGigApplication(id: number): Promise<boolean> {
    return false;
  }

  // VA Activities - stubbed
  async getVAActivities(userId: number, filters: any = {}): Promise<VAActivity[]> {
    return [];
  }

  async createVAActivity(activity: InsertVAActivity): Promise<VAActivity> {
    throw new Error('VA activities not yet implemented');
  }

  async updateVAActivity(id: number, activity: Partial<InsertVAActivity>): Promise<VAActivity | undefined> {
    return undefined;
  }

  async deleteVAActivity(id: number): Promise<boolean> {
    return false;
  }

  async getVAActivityStats(userId: number): Promise<{ totalActivities: number; thisMonth: number; avgDurationMin: number; completedTasks: number; pendingTasks: number }> {
    return {
      totalActivities: 0,
      thisMonth: 0,
      avgDurationMin: 0,
      completedTasks: 0,
      pendingTasks: 0
    };
  }


  // VA Assignments - stubbed
  async getVAAssignments(userId: number): Promise<VAAssignment[]> {
    return [];
  }

  async createVAAssignment(assignment: InsertVAAssignment): Promise<VAAssignment> {
    throw new Error('VA assignments not yet implemented');
  }

  async updateVAAssignment(id: number, assignment: Partial<InsertVAAssignment>): Promise<VAAssignment | undefined> {
    return undefined;
  }

  async deleteVAAssignment(id: number): Promise<boolean> {
    return false;
  }

  // Consent Grants - stubbed
  async getConsentGrants(userId: number): Promise<ConsentGrant[]> {
    return [];
  }

  async createConsentGrant(grant: InsertConsentGrant): Promise<ConsentGrant> {
    throw new Error('Consent grants not yet implemented');
  }

  async revokeConsentGrant(id: number): Promise<boolean> {
    return false;
  }

  // Audit Events - stubbed
  async getAuditEvents(userId: number, options: { limit?: number; offset?: number } = {}): Promise<AuditEvent[]> {
    return [];
  }

  async createAuditEvent(event: InsertAuditEvent): Promise<AuditEvent> {
    throw new Error('Audit events not yet implemented');
  }

  // Dismissed Recommendations
  async getDismissedRecommendations(userId: number): Promise<{ companyId: number; companyName: string; dismissedAt: Date; reason?: string }[]> {
    try {
      // For now, store dismissed recommendations in memory or a simple table structure
      // Since the dismissedRecommendations table doesn't exist yet, return empty array
      // This will be replaced once the database schema is updated
      return [];
    } catch (error) {
      console.error('Error getting dismissed recommendations:', error);
      return [];
    }
  }

  async dismissRecommendation(userId: number, companyId: number, companyName: string, reason?: string): Promise<void> {
    try {
      // For now, log the dismissal
      // This will be replaced once the database schema is updated
      console.log(`User ${userId} dismissed recommendation for company ${companyName} (${companyId})${reason ? ': ' + reason : ''}`);
      
      // In a full implementation, this would insert into dismissedRecommendations table:
      // await db.insert(dismissedRecommendations).values({
      //   userId,
      //   companyId,
      //   companyName,
      //   reason
      // });
    } catch (error) {
      console.error('Error dismissing recommendation:', error);
      throw error;
    }
  }

  // Document Management Methods
  async getUserDocuments(userId: string): Promise<any[]> {
    try {
      const userDocs = await db.select().from(documents).where(eq(documents.userId, parseInt(userId)));
      return userDocs;
    } catch (error) {
      console.error('Error getting user documents:', error);
      throw error;
    }
  }

  async createDocument(document: any): Promise<any> {
    try {
      const [newDocument] = await db.insert(documents).values({
        userId: document.userId,
        type: document.type,
        name: document.name,
        filename: document.filename,
        filepath: document.filepath,
        url: document.url,
        size: document.size,
        mimetype: document.mimetype,
        expirationDate: document.expirationDate
      }).returning();
      return newDocument;
    } catch (error) {
      console.error('Error creating document:', error);
      throw error;
    }
  }

  async deleteDocument(id: number, userId: string): Promise<boolean> {
    try {
      const result = await db.delete(documents)
        .where(and(eq(documents.id, id), eq(documents.userId, parseInt(userId))));
      return true;
    } catch (error) {
      console.error('Error deleting document:', error);
      return false;
    }
  }

  async getDocumentById(documentId: number, userId: string): Promise<any | undefined> {
    try {
      const [document] = await db.select().from(documents)
        .where(and(eq(documents.id, documentId), eq(documents.userId, parseInt(userId))));
      return document;
    } catch (error) {
      console.error('Error getting document by ID:', error);
      return undefined;
    }
  }

  // Business Documents methods
  async getBusinessDocuments(businessEntityId: number): Promise<BusinessDocument[]> {
    try {
      const docs = await db.select().from(businessDocuments)
        .where(eq(businessDocuments.businessEntityId, businessEntityId));
      return docs;
    } catch (error) {
      console.error('Error getting business documents:', error);
      return [];
    }
  }

  async getUserBusinessDocuments(userId: number): Promise<BusinessDocument[]> {
    try {
      const docs = await db.select().from(businessDocuments)
        .where(eq(businessDocuments.userId, userId));
      return docs;
    } catch (error) {
      console.error('Error getting user business documents:', error);
      return [];
    }
  }

  async getBusinessDocument(id: number): Promise<BusinessDocument | undefined> {
    try {
      const [doc] = await db.select().from(businessDocuments)
        .where(eq(businessDocuments.id, id));
      return doc;
    } catch (error) {
      console.error('Error getting business document:', error);
      return undefined;
    }
  }

  async createBusinessDocument(document: InsertBusinessDocument): Promise<BusinessDocument> {
    try {
      const [newDoc] = await db.insert(businessDocuments).values({
        userId: document.userId,
        businessEntityId: document.businessEntityId,
        documentName: document.documentName,
        documentType: document.documentType,
        documentCategory: document.documentCategory,
        fileName: document.fileName,
        fileUrl: document.fileUrl,
        filePath: document.filePath,
        fileSize: document.fileSize,
        mimeType: document.mimeType,
        notes: document.notes,
        status: document.status || 'active'
      }).returning();
      return newDoc;
    } catch (error) {
      console.error('Error creating business document:', error);
      throw error;
    }
  }

  async updateBusinessDocument(id: number, document: Partial<InsertBusinessDocument>): Promise<BusinessDocument | undefined> {
    try {
      const [updatedDoc] = await db.update(businessDocuments)
        .set(document)
        .where(eq(businessDocuments.id, id))
        .returning();
      return updatedDoc;
    } catch (error) {
      console.error('Error updating business document:', error);
      return undefined;
    }
  }

  async deleteBusinessDocument(id: number): Promise<boolean> {
    try {
      await db.delete(businessDocuments).where(eq(businessDocuments.id, id));
      return true;
    } catch (error) {
      console.error('Error deleting business document:', error);
      return false;
    }
  }
}

export const storage = new DatabaseStorage();
